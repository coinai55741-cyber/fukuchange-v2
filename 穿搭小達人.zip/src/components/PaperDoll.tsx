import React from 'react';
import { ClothingItem, ColorType, SlotType } from '../types';
import { playSound } from '../utils/audio';
import { Shirt, Footprints, Shield, User, HelpCircle, Delete } from 'lucide-react';

interface PaperDollProps {
  equippedItems: Record<SlotType, { item: ClothingItem; color: ColorType } | null>;
  selectedSlot: SlotType | null;
  onSelectSlot: (slot: SlotType) => void;
  onClearSlot: (slot: SlotType) => void;
  gender: '阿弟' | '阿妹';
  onChangeGender: () => void;
  restrictions?: string;
}

export const PaperDoll: React.FC<PaperDollProps> = ({
  equippedItems,
  selectedSlot,
  onSelectSlot,
  onClearSlot,
  gender,
  onChangeGender,
  restrictions
}) => {
  const slots: { name: SlotType; icon: React.ReactNode; top: string; left: string }[] = [
    { name: '頭部', icon: <span className="text-xs">頭</span>, top: '10%', left: '12%' },
    { name: '頸部', icon: <span className="text-xs">頸</span>, top: '23%', left: '12%' },
    { name: '軀幹', icon: <span className="text-xs">身</span>, top: '38%', left: '12%' },
    { name: '下身', icon: <span className="text-xs">褲</span>, top: '55%', left: '12%' },
    { name: '腿部', icon: <span className="text-xs">膝</span>, top: '70%', left: '12%' },
    { name: '腳部', icon: <span className="text-xs">腳</span>, top: '85%', left: '12%' },
  ];

  // Helper to render beautiful visual clothing pieces overlaid on the doll
  const renderVisualLayer = (slot: SlotType) => {
    const equipped = equippedItems[slot];
    if (!equipped) return null;

    const { item, color } = equipped;

    // Red floral pattern styling
    const isRedFloral = color.id === '紅色花圖案';
    const bgStyle = isRedFloral
      ? {
          backgroundColor: '#e11d48',
          backgroundImage: 'radial-gradient(#fecdd3 2px, transparent 2px), radial-gradient(#fecdd3 2px, transparent 2px)',
          backgroundSize: '12px 12px',
          backgroundPosition: '0 0, 6px 6px',
        }
      : { backgroundColor: color.hex };

    const textStyle = color.id === '烏色' || color.id === '吊菜色' ? 'text-white' : 'text-slate-800';

    switch (slot) {
      case '頭部':
        return (
          <div
            style={bgStyle}
            className={`absolute -top-3 left-1/2 -translate-x-1/2 w-28 h-12 rounded-t-full shadow-md flex flex-col items-center justify-center transition-all duration-300 z-30 border border-amber-900/10 ${textStyle}`}
          >
            <span className="font-sans text-xs font-semibold leading-tight">{color.id !== '無' ? color.id : ''}</span>
            <span className="font-sans text-xs font-bold">{item.name}</span>
          </div>
        );
      case '頸部':
        return (
          <div
            style={bgStyle}
            className={`absolute top-[23%] left-1/2 -translate-x-1/2 w-20 h-6 rounded-md shadow-md flex items-center justify-center transition-all duration-300 z-25 border border-amber-900/10 ${textStyle}`}
          >
            <span className="text-[10px] font-bold truncate px-1">{color.id !== '無' ? color.id : ''}{item.name}</span>
          </div>
        );
      case '軀幹':
        const isBlueShirt = item.name === '藍衫';
        const customBg = isBlueShirt ? { backgroundColor: '#1e3a8a' } : bgStyle; // Blue dye for traditional 藍衫
        return (
          <div
            style={customBg}
            className={`absolute top-[30%] left-1/2 -translate-x-1/2 w-36 h-28 rounded-md shadow-lg flex flex-col items-center justify-center transition-all duration-300 z-20 border border-amber-900/10 ${
              isBlueShirt ? 'text-yellow-300 border-l-4 border-yellow-400' : textStyle
            }`}
          >
            {isBlueShirt && <div className="absolute top-0 right-4 w-1 h-12 bg-yellow-400 rounded-b" />}
            <span className="text-[10px] uppercase tracking-wider font-semibold opacity-80">
              {isBlueShirt ? '傳統客庄' : (color.id !== '無' ? color.id : '')}
            </span>
            <span className="font-bold text-sm tracking-wide">{item.name}</span>
            {isBlueShirt && <span className="text-[9px] text-yellow-200 font-mono mt-1">Lâm-sâm</span>}
          </div>
        );
      case '下身':
        const isSkirt = item.name === '裙';
        return (
          <div
            style={bgStyle}
            className={`absolute top-[55%] left-1/2 -translate-x-1/2 h-20 shadow-md flex flex-col items-center justify-center transition-all duration-300 z-15 border border-amber-900/10 ${
              isSkirt ? 'w-36 rounded-b-3xl' : 'w-24 rounded-b-md'
            } ${textStyle}`}
          >
            {/* Draw pants split line if not a skirt */}
            {!isSkirt && <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0.5 h-12 bg-amber-950/20" />}
            <span className="text-[10px] font-semibold">{color.id !== '無' ? color.id : ''}</span>
            <span className="font-bold text-xs">{item.name}</span>
          </div>
        );
      case '腿部':
        return (
          <div className="absolute top-[71%] left-1/2 -translate-x-1/2 w-32 flex justify-between px-3 z-25">
            {[0, 1].map((i) => (
              <div
                key={i}
                style={bgStyle}
                className={`w-8 h-8 rounded-full border border-amber-900/20 shadow-md flex items-center justify-center ${textStyle}`}
              >
                <Shield size={10} className="stroke-2" />
              </div>
            ))}
          </div>
        );
      case '腳部':
        const isRainBoots = item.name === '水靴筒';
        return (
          <div className="absolute top-[82%] left-1/2 -translate-x-1/2 w-28 flex justify-between px-1 z-10">
            {[0, 1].map((i) => (
              <div
                key={i}
                style={bgStyle}
                className={`w-9 rounded-t-md shadow-md flex flex-col items-center justify-center border border-amber-900/20 ${
                  isRainBoots ? 'h-14 bg-emerald-700' : 'h-8'
                } ${textStyle}`}
              >
                <Footprints size={12} />
                <span className="text-[8px] font-bold leading-none mt-0.5">{item.name}</span>
              </div>
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-slate-50/50 rounded-2xl border border-slate-200/80 p-5 flex flex-col items-center relative overflow-hidden h-[540px]">
      {/* Background patterns */}

      <div className="text-center mb-1">
        <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">客庄紙娃娃穿搭展示區</h3>
      </div>

      {/* Main Avatar Drawing area */}
      <div id="paper-doll-canvas" className="relative w-full flex-1 max-w-[280px] bg-white rounded-xl border border-slate-100 shadow-inner flex items-center justify-center">
        {/* Silhouette avatar sketch */}
        <div className="absolute inset-0 flex flex-col items-center justify-center opacity-10 pointer-events-none select-none">
          <User size={220} className="text-slate-900" />
        </div>

        {/* Paper Doll Human Structure */}
        <div className="relative w-full h-[400px]">
          {/* Head & Neck Base */}
          <div className="absolute top-[5%] left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-orange-100 border border-orange-200 flex flex-col items-center justify-center z-10">
            {/* Simple face */}
            <div className="flex gap-3 mt-4">
              <div className="w-1.5 h-1.5 bg-slate-700 rounded-full" />
              <div className="w-1.5 h-1.5 bg-slate-700 rounded-full" />
            </div>
            <div className="w-4 h-1.5 border-b-2 border-slate-500 rounded-b-full mt-1" />
            {gender === '阿妹' && (
              <div className="absolute -top-1 w-18 h-4 bg-slate-800 rounded-t-full -z-10" />
            )}
          </div>
          <div className="absolute top-[18%] left-1/2 -translate-x-1/2 w-4 h-8 bg-orange-100 border-x border-orange-200 z-5" />

          {/* Torso Base */}
          <div className="absolute top-[23%] left-1/2 -translate-x-1/2 w-24 h-32 bg-orange-50 border border-orange-100 rounded-t-lg -z-5" />

          {/* Legs Base */}
          <div className="absolute top-[55%] left-1/2 -translate-x-1/2 w-16 h-36 flex justify-between px-1 -z-10">
            <div className="w-6 h-full bg-orange-50 border-x border-b border-orange-100 rounded-b" />
            <div className="w-6 h-full bg-orange-50 border-x border-b border-orange-100 rounded-b" />
          </div>

          {/* Render Active Clothing Layers */}
          {renderVisualLayer('頭部')}
          {renderVisualLayer('頸部')}
          {renderVisualLayer('軀幹')}
          {renderVisualLayer('下身')}
          {renderVisualLayer('腿部')}
          {renderVisualLayer('腳部')}
        </div>

        {/* Floating Slot Buttons on Left side for interactive slot choosing */}
        <div data-html2canvas-ignore="true" className="absolute left-3 top-1/2 -translate-y-1/2 flex flex-col gap-2.5 z-40">
          {slots.map((s) => {
            const hasEquipped = !!equippedItems[s.name];
            const isSelected = selectedSlot === s.name;

            return (
              <div key={s.name} className="flex items-center gap-1.5 group">
                <button
                  onClick={() => {
                    playSound.click();
                    onSelectSlot(s.name);
                  }}
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold shadow-md transition-all duration-200 ${
                    isSelected
                      ? 'bg-teal-600 text-white ring-4 ring-teal-100 scale-105'
                      : hasEquipped
                      ? 'bg-emerald-50 text-emerald-700 border-2 border-emerald-500'
                      : 'bg-white text-slate-500 border border-slate-200 hover:border-slate-300'
                  }`}
                  title={`選擇${s.name}插槽`}
                >
                  {s.icon}
                </button>
                <div className="opacity-0 group-hover:opacity-100 transition duration-150 bg-slate-800 text-white text-[10px] px-2 py-0.5 rounded shadow absolute left-12 whitespace-nowrap pointer-events-none">
                  {s.name}
                  {hasEquipped && `: ${equippedItems[s.name]?.item.name}`}
                </div>
                {hasEquipped && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      playSound.equip();
                      onClearSlot(s.name);
                    }}
                    className="w-5 h-5 rounded-md bg-rose-50 text-rose-500 hover:bg-rose-100 border border-rose-200 flex items-center justify-center transition"
                    title="卸下此配件"
                  >
                    ×
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-3 text-center w-full bg-slate-100/60 rounded-xl p-2.5 border border-slate-200/50">
        <p className="text-xs font-semibold text-slate-600">
          {selectedSlot ? (
            <span>
              正在裝扮插槽：<strong className="text-teal-600 font-bold">{selectedSlot}</strong>
            </span>
          ) : (
            <span className="text-slate-400">點擊右側衣物開始著裝</span>
          )}
        </p>
      </div>
    </div>
  );
};
