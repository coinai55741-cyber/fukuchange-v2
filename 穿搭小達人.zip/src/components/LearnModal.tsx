import React, { useState } from 'react';
import { items as defaultItemDatabase, colors as defaultColorPalette } from '../data/questions';
import { playSound } from '../utils/audio';
import { BookOpen, Search, X } from 'lucide-react';

// Custom beautifully styled vector illustrations for each clothing item
const ShortShirtSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14 18 L24 10 H40 L50 18 L44 26 L38 22 V54 H26 V22 L20 26 Z" fill="#38bdf8" stroke="#0284c7" strokeWidth={2} strokeLinejoin="round" />
    <path d="M26 10 C26 14 38 14 38 10" stroke="#0284c7" strokeWidth={2} />
    <line x1="26" y1="32" x2="38" y2="32" stroke="#0284c7" strokeWidth={1.5} strokeDasharray="3 3" />
  </svg>
);

const TrousersSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 10 H44 V26 L40 54 H31 V30 L24 54 H15 V26 Z" fill="#475569" stroke="#1e293b" strokeWidth={2} strokeLinejoin="round" />
    <line x1="20" y1="16" x2="44" y2="16" stroke="#1e293b" strokeWidth={1.5} />
  </svg>
);

const ShortsSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 12 H46 V32 L38 32 L36 42 H28 L26 32 L18 32 Z" fill="#64748b" stroke="#334155" strokeWidth={2} strokeLinejoin="round" />
    <line x1="18" y1="18" x2="46" y2="18" stroke="#334155" strokeWidth={1.5} />
  </svg>
);

const SkirtSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M24 14 H40 L48 48 H16 Z" fill="#f43f5e" stroke="#be123c" strokeWidth={2} strokeLinejoin="round" />
    <path d="M20 48 V22 M26 48 V18 M32 48 V14 M38 48 V18 M44 48 V22" stroke="#be123c" strokeWidth={1.5} strokeLinecap="round" />
  </svg>
);

const DownJacketSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14 20 L22 14 H42 L50 20 L44 54 H20 Z" fill="#0ea5e9" stroke="#0369a1" strokeWidth={2} strokeLinejoin="round" />
    <path d="M20 26 H44 M20 34 H44 M20 42 H44 M20 50 H44" stroke="#0369a1" strokeWidth={1.5} />
    <path d="M32 14 V54" stroke="#f59e0b" strokeWidth={2} strokeLinecap="round" />
  </svg>
);

const SweaterSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16 18 L24 12 H40 L48 18 L46 50 H18 Z" fill="#f59e0b" stroke="#b45309" strokeWidth={2} strokeLinejoin="round" />
    <path d="M22 20 Q24 22 26 20 T30 20 T34 20 T38 20 T42 20" stroke="#b45309" strokeWidth={1.5} fill="none" />
    <path d="M22 28 Q24 30 26 28 T30 28 T34 28 T38 28 T42 28" stroke="#b45309" strokeWidth={1.5} fill="none" />
    <path d="M22 36 Q24 38 26 36 T30 36 T34 36 T38 36 T42 36" stroke="#b45309" strokeWidth={1.5} fill="none" />
    <path d="M22 44 Q24 46 26 44 T30 44 T34 44 T38 44 T42 44" stroke="#b45309" strokeWidth={1.5} fill="none" />
  </svg>
);

const ScarfSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 20 C18 14, 46 14, 46 20 C46 26, 18 26, 18 32 C18 38, 46 38, 46 44" stroke="#e11d48" strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
    <path d="M41 40 V54" stroke="#e11d48" strokeWidth={4} strokeLinecap="round" />
    <path d="M46 40 V50" stroke="#e11d48" strokeWidth={4} strokeLinecap="round" />
    <line x1={41} y1={54} x2={41} y2={58} stroke="#fda4af" strokeWidth={2} />
    <line x1={46} y1={50} x2={46} y2={54} stroke="#fda4af" strokeWidth={2} />
  </svg>
);

const ShoesSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14 36 H44 L48 24 L38 20 L28 24 L20 30 Z" fill="#14b8a6" stroke="#0f766e" strokeWidth={2} strokeLinejoin="round" />
    <path d="M12 36 H46 V40 H12 Z" fill="#f1f5f9" stroke="#0f766e" strokeWidth={2} strokeLinejoin="round" />
    <path d="M28 24 L32 28 M30 22 L34 26" stroke="#ffffff" strokeWidth={2} strokeLinecap="round" />
  </svg>
);

const RainBootsSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 14 H34 V42 L44 46 V52 H18 V46 L20 42 Z" fill="#047857" stroke="#064e3b" strokeWidth={2} strokeLinejoin="round" />
    <path d="M16 50 H46 V54 H16 Z" fill="#1e293b" stroke="#064e3b" strokeWidth={2} strokeLinejoin="round" />
    <path d="M20 14 H34 V18 H20 Z" fill="#f59e0b" />
  </svg>
);

const HatSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M32 10 L54 36 H10 Z" fill="#fef08a" stroke="#ca8a04" strokeWidth={2} strokeLinejoin="round" />
    <path d="M32 10 V36 M21 22 L43 22 M16 28 L48 28" stroke="#ca8a04" strokeWidth={1} />
    <path d="M26 36 L32 50 L38 36" stroke="#b45309" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const KneepadsSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x={18} y={16} width={28} height={32} rx={4} fill="#3b82f6" stroke="#1d4ed8" strokeWidth={2} />
    <ellipse cx={32} cy={32} rx={9} ry={12} fill="#1d4ed8" stroke="#172554" strokeWidth={1.5} />
    <circle cx={32} cy={26} r={1.5} fill="#93c5fd" />
    <circle cx={32} cy={38} r={1.5} fill="#93c5fd" />
  </svg>
);

const BlueShirtSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 20 L24 10 H40 L52 20 L44 28 L38 24 V54 H22 V24 L16 28 Z" fill="#1e3a8a" stroke="#172554" strokeWidth={2} strokeLinejoin="round" />
    <path d="M28 10 C28 15, 34 18, 38 18 C39 20, 39 30, 39 36" stroke="#facc15" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
    <circle cx={38} cy={22} r={2} fill="#facc15" />
    <circle cx={38} cy={28} r={2} fill="#facc15" />
    <circle cx={38} cy={34} r={2} fill="#facc15" />
  </svg>
);

const SwimCapSvg = () => (
  <svg className="w-full h-full" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14 36 C14 18, 50 18, 50 36 C50 38, 44 40, 32 40 C20 40, 14 38, 14 36 Z" fill="#ec4899" stroke="#9d174d" strokeWidth={2} strokeLinejoin="round" />
    <path d="M20 28 C28 22, 36 22, 44 28" stroke="#fbcfe8" strokeWidth={1.5} strokeLinecap="round" />
  </svg>
);

const ClothingIllustration: React.FC<{ name: string }> = ({ name }) => {
  switch (name) {
    case '短衫':
      return <ShortShirtSvg />;
    case '長褲':
      return <TrousersSvg />;
    case '短褲':
      return <ShortsSvg />;
    case '裙':
      return <SkirtSvg />;
    case '羽絨衫':
      return <DownJacketSvg />;
    case '膨線衫':
      return <SweaterSvg />;
    case '頸圍仔':
      return <ScarfSvg />;
    case '鞋':
      return <ShoesSvg />;
    case '水靴筒':
      return <RainBootsSvg />;
    case '帽仔':
      return <HatSvg />;
    case '膝頭落仔':
      return <KneepadsSvg />;
    case '藍衫':
      return <BlueShirtSvg />;
    case '泅水帽':
      return <SwimCapSvg />;
    default:
      return null;
  }
};

interface LearnModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemDatabase?: typeof defaultItemDatabase;
  colorPalette?: typeof defaultColorPalette;
}

export const LearnModal: React.FC<LearnModalProps> = ({ 
  isOpen, 
  onClose,
  itemDatabase = defaultItemDatabase,
  colorPalette = defaultColorPalette
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredItems = itemDatabase.filter(
    (item) =>
      item.name.includes(searchQuery) ||
      item.translation.includes(searchQuery) ||
      item.phonetic.includes(searchQuery)
  );

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-slate-100">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-700 to-emerald-700 p-5 text-white flex justify-between items-center">
          <div className="flex items-center gap-2">
            <BookOpen size={20} className="text-teal-200" />
            <div>
              <h2 className="text-lg font-bold tracking-wide">客庄衣著小詞典</h2>
              <p className="text-xs text-teal-100 mt-0.5">學習正宗客家穿衣名詞與發音</p>
            </div>
          </div>
          <button
            onClick={() => {
              playSound.click();
              onClose();
            }}
            className="p-1.5 hover:bg-white/15 rounded-lg transition text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-4 border-b border-slate-100 flex gap-2 bg-slate-50">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜尋客語名詞、華語翻譯或拼音..."
              className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-100 focus:border-teal-500 transition"
            />
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="px-3 py-2 text-xs text-slate-500 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition"
            >
              重設
            </button>
          )}
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {filteredItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredItems.map((item) => (
                <div
                  key={item.name}
                  className="p-4 border border-slate-100 bg-white hover:border-teal-100 hover:bg-teal-50/10 rounded-xl transition duration-150 flex gap-4 items-start"
                >
                  <div className="w-16 h-16 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center p-2 shadow-inner shrink-0 mt-1">
                    <ClothingIllustration name={item.name} />
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-between h-full">
                    <div>
                      <div className="flex justify-between items-start mb-1 gap-2">
                        <span className="text-base font-bold text-slate-800 truncate">
                          {item.name}
                        </span>
                      </div>

                      <div className="text-xs font-mono text-amber-700 font-semibold mb-1.5">
                        拼音: {item.phonetic}
                      </div>

                      <div className="text-xs text-slate-500 leading-relaxed">
                        <strong className="text-slate-700 font-semibold">釋義:</strong> {item.translation}
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 mt-3 border-t border-slate-100 pt-2.5 leading-relaxed">
                      <span className="inline-block text-[10px] text-teal-800 bg-teal-50 border border-teal-100/50 px-1.5 py-0.5 rounded-md font-extrabold mr-1.5 select-none">
                        小知識
                      </span>
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 text-sm">
              沒有找到符合「{searchQuery}」的客家衣著詞彙。
            </div>
          )}

          {/* Color Section inside dictionary */}
          <div className="border-t border-slate-100 pt-5 mt-4">
            <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-1.5">
              <span>🎨 客語顏色名詞</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {colorPalette.filter(col => col.id !== '無').map((col) => (
                <div
                  key={col.id}
                  className="p-2 border border-slate-100 rounded-lg flex items-center gap-2.5 bg-slate-50/50"
                >
                  <div
                    className="w-5 h-5 rounded-full border border-slate-300"
                    style={{
                      backgroundColor: col.id === '紅色花圖案' ? '#ec4899' : col.hex,
                      backgroundImage: col.id === '紅色花圖案' ? 'radial-gradient(#fbcfe8 2.5px, transparent 2.5px)' : 'none',
                      backgroundSize: '5px 5px',
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] font-mono font-black text-amber-700 bg-amber-50 px-1 py-0.5 rounded border border-amber-100/40 truncate" title={col.phonetic}>
                      {col.phonetic || ''}
                    </div>
                    <div className="text-xs font-extrabold text-slate-800 mt-1 flex items-center gap-1.5 flex-wrap">
                      <span>{col.id}</span>
                      {col.translation && col.translation !== col.id && (
                        <span className="text-[9px] text-slate-400 font-normal">({col.translation})</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-100 text-right">
          <button
            onClick={() => {
              playSound.click();
              onClose();
            }}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold shadow-sm transition"
          >
            關閉詞典
          </button>
        </div>
      </div>
    </div>
  );
};
