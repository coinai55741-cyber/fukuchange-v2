import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Question, ClothingItem, ColorType, GamePhase, SlotType } from '../types';
import { items as defaultItemDatabase, colors as defaultColorPalette } from '../data/questions';
import { playSound } from '../utils/audio';
import { HelpCircle, ChevronLeft, ChevronRight, CheckCircle2, RotateCcw, AlertTriangle, Lightbulb, Timer, Camera, Trophy } from 'lucide-react';

interface MissionCardProps {
  currentQuestion: Question;
  currentIndex: number;
  totalQuestions: number;
  gamePhase: GamePhase;
  onChangePhase: (phase: GamePhase) => void;
  onNextQuestion: () => void;
  onPrevQuestion: () => void;
  equippedItems: Record<SlotType, { item: ClothingItem; color: ColorType } | null>;
  lastEquipped?: { item: ClothingItem; color: ColorType } | null;
  onClearAllSlots: () => void;
  onJumpToQuestion: (index: number) => void;
  questionResults: Record<number, boolean>;
  setQuestionResults: React.Dispatch<React.SetStateAction<Record<number, boolean>>>;
  questionScores: Record<number, number>;
  isAllCompleted: boolean;
  gameMode: 'structured' | 'random';
  onRestart: () => void;
  onEquipItem?: (item: ClothingItem, color: ColorType) => void;
  onRecordAnswer?: (questionId: number, answerText: string, isCorrect: boolean, scorePoints?: number) => void;
  timeElapsedMs: number;
  itemDatabase?: ClothingItem[];
  colorPalette?: ColorType[];
}

const colorPhoneticMap: { [key: string]: string } = {
  "柑仔色": "gamˊ eˋ sedˋ",
  "黃色": "vongˇ sedˋ",
  "白色": "pag sedˋ",
  "烏色": "vuˊ sedˋ",
  "吊菜色": "diau coi sedˋ",
  "紅色花圖案": "fungˇ sedˋ faˊ bu",
  "無": "moˇ",
  "無染色": "moˇ"
};

export const MissionCard: React.FC<MissionCardProps> = ({
  currentQuestion,
  currentIndex,
  totalQuestions,
  gamePhase,
  onChangePhase,
  onNextQuestion,
  onPrevQuestion,
  equippedItems,
  lastEquipped,
  onClearAllSlots,
  onJumpToQuestion,
  questionResults,
  setQuestionResults,
  questionScores,
  isAllCompleted,
  gameMode,
  onRestart,
  onEquipItem,
  onRecordAnswer,
  timeElapsedMs,
  itemDatabase = defaultItemDatabase,
  colorPalette = defaultColorPalette
}) => {
  // Local state for the randomly chosen allowed answer
  const [targetAnswer, setTargetAnswer] = useState<{ verb: '著' | '戴'; color: string; item: string } | null>(null);
  const [blankType, setBlankType] = useState<'color' | 'item' | 'none'>('none');

  // Local state for dropdown selectors
  const [selectedVerb, setSelectedVerb] = useState<'著' | '戴'>('著');
  const [selectedItemName, setSelectedItemName] = useState<string>('短衫');
  const [selectedColorName, setSelectedColorName] = useState<string>('無');
  const [showHint, setShowHint] = useState<boolean>(false);
  const [countdownToNext, setCountdownToNext] = useState<number | null>(null);
  const [alertMessage, setAlertMessage] = useState<{ type: 'success' | 'error' | 'warning' | null; text: string | null }>({
    type: null,
    text: null
  });

  // Randomly select one target answer when question changes to pre-populate elements
  useEffect(() => {
    if (currentQuestion && currentQuestion.allowedAnswers.length > 0) {
      // Clear all clothing slots so they start each round completely unequipped
      if (onClearAllSlots) {
        onClearAllSlots();
      }

      // Pick a random allowed answer (動詞是隨機出題)
      const randomIndex = Math.floor(Math.random() * currentQuestion.allowedAnswers.length);
      const rawAns = currentQuestion.allowedAnswers[randomIndex];
      
      const parts = rawAns.split(' ');
      const verb = parts[0] as '著' | '戴';
      const rest = parts.slice(1).join(' ');
      let color = '無';
      let item = rest;
      
      if (rest.includes('个')) {
        const subParts = rest.split('个');
        color = subParts[0];
        item = subParts[1];
      }
      
      setTargetAnswer({ verb, color, item });

      if (currentIndex < 5) {
        setBlankType('none');
        setSelectedVerb(verb);
        setSelectedColorName(color); // Fix color - no blank
        setSelectedItemName(item);   // Fix item - no blank
      } else {
        // For levels 6-10, 50% chance of either color blank or item blank!
        // If color is '無', force item blank!
        const chosenBlankType = (color === '無' || color === '') ? 'item' : (Math.random() < 0.5 ? 'color' : 'item');
        setBlankType(chosenBlankType);

        // Questions 6-10: Purple box is fixed answer displaying Hakka Pinyin, no interactive choice
        setSelectedColorName(color);
        setSelectedItemName(item);
        setSelectedVerb(verb);
      }
    }
  }, [currentQuestion.id, currentIndex]);

  // Sync paper doll's equipped items back to fields when lastEquipped changes
  useEffect(() => {
    if (!lastEquipped) return;
    if (currentIndex >= 5) return;

    if (currentIndex < 5) {
      // For levels 1-5, no blanks, but we sync if they dye the target item
      if (lastEquipped.item.name === targetAnswer?.item) {
        setSelectedColorName(lastEquipped.color.id);
      }
    } else {
      // For levels 6-10 (fill-in-the-blank levels)
      const targetItemDb = targetAnswer ? itemDatabase.find(i => i.name === targetAnswer.item) : null;
      const targetSlot = targetItemDb?.slot;

      if (blankType === 'color') {
        // Fill the color blank ONLY if they equipped or dyed the target clothing item
        if (lastEquipped.item.name === targetAnswer?.item) {
          setSelectedColorName(lastEquipped.color.id);
          setSelectedVerb(lastEquipped.item.verb);
        }
      } else if (blankType === 'item') {
        // Fill the item blank ONLY if they equipped an item belonging to the target item's slot (e.g. body/head/feet)
        if (targetSlot && lastEquipped.item.slot === targetSlot) {
          setSelectedItemName(lastEquipped.item.name);
          setSelectedVerb(lastEquipped.item.verb);
          // Also sync color if it matches the target color
          if (lastEquipped.color.id === targetAnswer?.color) {
            setSelectedColorName(lastEquipped.color.id);
          }
        }
      }
    }
  }, [lastEquipped, blankType, currentIndex, targetAnswer, itemDatabase]);

  // Reset alert message, hint, and timer when currentQuestion changes
  useEffect(() => {
    setAlertMessage({ type: null, text: null });
    setShowHint(false);
    setCountdownToNext(null);
  }, [currentQuestion.id]);

  // Handle automatic auto-advance countdown to the next question
  useEffect(() => {
    if (countdownToNext === null) return;
    if (countdownToNext <= 0) {
      setCountdownToNext(null);
      if (currentIndex < totalQuestions - 1) {
        onNextQuestion();
      }
      return;
    }
    const t = setTimeout(() => {
      setCountdownToNext(prev => prev !== null ? prev - 1 : null);
    }, 1000);
    return () => clearTimeout(t);
  }, [countdownToNext, currentIndex, totalQuestions, onNextQuestion]);

  // Handle manual dropdown or text input changes
  const handleDropdownSubmit = () => {
    // Check if "身" (軀幹), "褲" (下身), and "腳" (腳部) are all equipped!
    const bodyEquipped = equippedItems['軀幹'];
    const pantsEquipped = equippedItems['下身'];
    const feetEquipped = equippedItems['腳部'];

    if (!bodyEquipped || !pantsEquipped || !feetEquipped) {
      playSound.fail();
      setAlertMessage({
        type: 'warning',
        text: '上身、下身及鞋子三個區域，都要穿上才能出門喔！'
      });
      return;
    }

    const targetItemName = targetAnswer?.item || '';
    const targetColorName = targetAnswer?.color || '無';
    const targetVerb = targetAnswer?.verb || '著';

    // 1. Determine what the constructed answer should be based on equipped state
    let finalColor = '無';
    let finalItem = '';
    let finalVerb: '著' | '戴' = '著';

    if (currentIndex < 5) {
      // Phase 1: Fixed color and item
      finalColor = targetColorName;
      finalItem = targetItemName;
      finalVerb = targetVerb;
    } else {
      // Phase 2: One blank
      if (blankType === 'color') {
        finalItem = targetItemName;
        finalVerb = targetVerb;
        finalColor = selectedColorName || '無';
      } else {
        finalItem = selectedItemName || '';
        finalColor = targetColorName;
        const dbItem = itemDatabase.find(i => i.name === finalItem);
        finalVerb = dbItem ? dbItem.verb : '著';
      }
    }

    // Guard: Must have non-empty inputs
    if (finalItem === '') {
      playSound.fail();
      setAlertMessage({
        type: 'warning',
        text: '【客庄智慧提示】請先點擊右側【客庄衣櫃】選配衣服穿上，再送出驗證喔！'
      });
      return;
    }

    // Construct the validation string and validate directly
    const expectedColorId = (finalColor === '' || finalColor === '無染色') ? '無' : finalColor;
    const constructedAnswer = (expectedColorId === '無')
      ? `${finalVerb} ${finalItem}`
      : `${finalVerb} ${expectedColorId}个${finalItem}`;

    validateAnswerString(constructedAnswer);
  };



  const validateAnswerString = (constructedAnswer: string, shouldProceedAfterValidation: boolean = false) => {
    // Prevent double submission or submitting during countdown
    if (countdownToNext !== null || questionResults[currentQuestion.id] === true) return;

    const isFirstTry = questionScores[currentQuestion.id] === undefined;

    // Check "題目對" (itemMatch and colorMatch)
    const targetItemDb = (itemDatabase || defaultItemDatabase).find(i => i.name === targetAnswer?.item);
    const targetSlot = targetItemDb?.slot || '軀幹';
    const equippedAtTargetSlot = equippedItems[targetSlot];

    const itemMatch = equippedAtTargetSlot?.item.name === targetAnswer?.item;
    const expectedColorId = (targetAnswer?.color === '' || targetAnswer?.color === '無染色') ? '無' : (targetAnswer?.color || '無');
    const equippedColorId = equippedAtTargetSlot?.color.id || '無';
    const actualColorId = (equippedColorId === '' || equippedColorId === '無染色') ? '無' : equippedColorId;
    const colorMatch = actualColorId === expectedColorId;

    const isQuestionMatch = !!(itemMatch && colorMatch); // 題目對

    // Check "情境對" (Entire outfit context validation)
    const checkOutfitContextMatch = (): { match: boolean; reason?: string; isSeasonalConflict?: boolean } => {
      // 1. Temperature check
      const restrictionsStr = currentQuestion.restrictions || '';
      const isQuestionHot = restrictionsStr.includes('熱');
      const isQuestionCold = restrictionsStr.includes('冷');

      // Get all currently equipped items
      const equippedList = Object.values(equippedItems).filter(Boolean) as { item: ClothingItem; color: ColorType }[];

      for (const eq of equippedList) {
        const itemTags = Array.isArray(eq.item.tags)
          ? eq.item.tags.map(t => t.trim())
          : typeof eq.item.tags === 'string'
            ? (eq.item.tags as string).split(';').map(t => t.trim())
            : [];
        const hasHotTag = itemTags.includes('熱') || itemTags.some(t => t.includes('熱'));
        const hasColdTag = itemTags.includes('冷') || itemTags.some(t => t.includes('冷'));

        // Name-based fallback for seasonal conflict
        const isWinterItem = ['羽絨衫', '膨線衫', '頸圍仔'].includes(eq.item.name);
        const isSummerItem = ['短衫', '短褲', '裙'].includes(eq.item.name);

        if (isQuestionHot && (hasColdTag || isWinterItem) && !hasHotTag) {
          return {
            match: false,
            isSeasonalConflict: true,
            reason: `大熱天（夏天）穿「${eq.item.name}」會熱得滿身大汗喔！請換上適合夏天的衣物。`
          };
        }
        if (isQuestionCold && (hasHotTag || isSummerItem) && !hasColdTag) {
          return {
            match: false,
            isSeasonalConflict: true,
            reason: `大冷天（冬天）穿「${eq.item.name}」會冷到發抖喔！請換上適合冬天的禦寒衣物。`
          };
        }
      }

      // 2. Specific question ID constraints
      // Q4: Watching Fireflies (賞螢, 暗, 熱)
      if (currentQuestion.id === 4) {
        for (const eq of equippedList) {
          if (eq.item.name === '短褲' || eq.item.name === '裙') {
            return {
              match: false,
              reason: '看螢火蟲會穿過草叢，穿短褲/短裙會被蚊子咬得滿腳紅腫喔！請穿著「長褲」。'
            };
          }
          const colorId = eq.color.id;
          if (colorId === '白色' || colorId === '黃色' || colorId === '柑仔色' || colorId === '紅色花圖案') {
            return {
              match: false,
              reason: `螢火蟲害怕強光，穿「${colorId}」的「${eq.item.name}」反射光線會嚇跑牠們！請穿暗色衣物。`
            };
          }
        }
      }

      // Q8: Formal Interview (正式)
      if (currentQuestion.id === 8) {
        for (const eq of equippedList) {
          if (eq.item.name === '短褲' || eq.item.name === '羽絨衫' || eq.item.name === '膨線衫') {
            return {
              match: false,
              reason: `面試需要專業體面，穿著過於休閒的「${eq.item.name}」不夠莊重。`
            };
          }
          const colorId = eq.color.id;
          if (colorId === '柑仔色' || colorId === '黃色' || colorId === '紅色花圖案') {
            return {
              match: false,
              reason: `正式的面試場合，穿著「${colorId}」的「${eq.item.name}」過於刺眼花俏，會不夠莊重。`
            };
          }
        }
      }

      // Q9: Cleaning (打掃)
      if (currentQuestion.id === 9) {
        for (const eq of equippedList) {
          const colorId = eq.color.id;
          if (colorId === '白色' || colorId === '黃色' || colorId === '柑仔色') {
            return {
              match: false,
              reason: `大掃除容易弄髒衣服，穿「${colorId}」的「${eq.item.name}」極易弄髒染色！請選穿深色（烏色、吊菜色）衣物。`
            };
          }
        }
      }

      // Q10: Art Class / Drawing (日常, 美術課)
      if (currentQuestion.id === 10) {
        for (const eq of equippedList) {
          const colorId = eq.color.id;
          if (colorId === '白色' || colorId === '黃色' || colorId === '柑仔色') {
            return {
              match: false,
              reason: `美術課畫水彩容易弄髒衣服，穿「${colorId}」的「${eq.item.name}」沾上水彩就洗不掉囉！請改穿深色或紅色花圖案衣物。`
            };
          }
        }
      }

      return { match: true };
    };

    const contextCheck = checkOutfitContextMatch();
    const isContextMatch = contextCheck.match;

    // Determine Tier & score
    let tier = 4;
    let computedScore = 0;
    
    if (isQuestionMatch && isContextMatch) {
      tier = 1;
      computedScore = 10;
    } else if (isQuestionMatch && !isContextMatch) {
      tier = 2;
      computedScore = 6;
    } else if (!isQuestionMatch && !contextCheck.isSeasonalConflict) {
      tier = 3;
      computedScore = 4;
    } else {
      tier = 4;
      computedScore = 0;
    }

    if (tier === 1) {
      playSound.success();
      setQuestionResults(prev => ({ ...prev, [currentQuestion.id]: true }));
      
      const scoreToRecord = isFirstTry ? 10 : undefined;
      onRecordAnswer?.(currentQuestion.id, constructedAnswer, true, scoreToRecord);

      const text = isFirstTry
        ? `【完全正確！本題獲得 10 分】恭喜你！既達成了題目要求的「${constructedAnswer}」，又完美契合了客庄情境！`
        : `【恭喜通關！】你已成功搭配出正確裝扮！本題將記錄你的首次送出分數：${questionScores[currentQuestion.id] || 0} 分。`;

      setAlertMessage({
        type: 'success',
        text
      });
      setCountdownToNext(2); // 2 seconds to transition to next question
    } else {
      const scoreToRecord = isFirstTry ? computedScore : undefined;
      onRecordAnswer?.(currentQuestion.id, constructedAnswer, false, scoreToRecord);

      if (shouldProceedAfterValidation) {
        if (!(currentQuestion.id in questionResults)) {
          setQuestionResults(prev => ({ ...prev, [currentQuestion.id]: false }));
        }
        onClearAllSlots();
        if (currentIndex < totalQuestions - 1) {
          onNextQuestion();
        } else {
          setAlertMessage({
            type: 'warning',
            text: '本題已送出分數，即將結算成績！'
          });
        }
        return;
      }

      playSound.fail();
      
      const defaultErrorReason = `「${constructedAnswer}」不符合這個場合的安全、溫度或傳統習俗！`;
      const errorReason = contextCheck.reason || defaultErrorReason;

      let text = '';
      if (isFirstTry) {
        if (tier === 2) {
          text = `【達成題目，情境不符！本題獲得 6 分】你選對了題目要求的衣物，但這套穿搭不符合當前場合的情境喔！例如：${errorReason} 請重新調整搭配，挑戰完美通關！`;
        } else if (tier === 3) {
          text = `【達成情境，題目不符！本題獲得 4 分】你的搭配符合當前的天氣與環境情境，但不是題目最想讓你練習的客語「${targetAnswer?.color && targetAnswer.color !== '無' ? targetAnswer.color + '个 ' : ''}${targetAnswer?.item}」喔！請重新調整搭配，挑戰完美通關！`;
        } else {
          text = `【不符合要求！本題獲得 0 分】這件衣物與顏色不符合題目要求，也不符合場合的情境喔！例如：${errorReason} 請重新調整搭配，挑戰完美通關！`;
        }
      } else {
        text = `【搭配仍未完全正確】請繼續調整搭配，直到完全正確以利通關喔！（本題將記錄你的首次送出分數為：${questionScores[currentQuestion.id] || 0} 分）`;
      }

      setAlertMessage({
        type: 'error',
        text
      });
      // Do NOT set countdownToNext so they stay on this page to edit and try again!
    }
  };

  const handleManualReset = () => {
    playSound.click();
    onClearAllSlots();
  };

  const handleSkipQuestion = () => {
    playSound.click();
    const isFirstTry = questionScores[currentQuestion.id] === undefined;
    // Record as false if not already answered
    if (!(currentQuestion.id in questionResults)) {
      setQuestionResults(prev => ({ ...prev, [currentQuestion.id]: false }));
    }
    // Also record 0 points for score if first try!
    onRecordAnswer?.(currentQuestion.id, "已跳過", false, isFirstTry ? 0 : undefined);
    onClearAllSlots();
    if (currentIndex < totalQuestions - 1) {
      onNextQuestion();
    } else {
      setAlertMessage({
        type: 'warning',
        text: '最後一關已跳過，即將結算成績！'
      });
    }
  };

  const handleProceedWithCurrentScore = () => {
    playSound.click();

    // 1. If they have already submitted at least once, then the score is already recorded.
    if (questionScores[currentQuestion.id] !== undefined) {
      if (!(currentQuestion.id in questionResults)) {
        setQuestionResults(prev => ({ ...prev, [currentQuestion.id]: false }));
      }
      onClearAllSlots();
      if (currentIndex < totalQuestions - 1) {
        onNextQuestion();
      } else {
        setAlertMessage({
          type: 'warning',
          text: '本題已送出分數，即將結算成績！'
        });
      }
      return;
    }

    // 2. If they haven't submitted yet, let's calculate the constructed answer and validate it with "shouldProceedAfterValidation" flag!
    const targetItemName = targetAnswer?.item || '';
    const targetColorName = targetAnswer?.color || '無';
    const targetVerb = targetAnswer?.verb || '著';

    let finalColor = '無';
    let finalItem = '';
    let finalVerb: '著' | '戴' = '著';

    if (currentIndex < 5) {
      finalColor = targetColorName;
      finalItem = targetItemName;
      finalVerb = targetVerb;
    } else {
      if (blankType === 'color') {
        finalItem = targetItemName;
        finalVerb = targetVerb;
        finalColor = selectedColorName || '無';
      } else {
        finalItem = selectedItemName || '';
        finalColor = targetColorName;
        const dbItem = itemDatabase.find(i => i.name === finalItem);
        finalVerb = dbItem ? dbItem.verb : '著';
      }
    }

    // If they literally haven't equipped anything, record 0 points and proceed
    if (finalItem === '') {
      if (!(currentQuestion.id in questionResults)) {
        setQuestionResults(prev => ({ ...prev, [currentQuestion.id]: false }));
      }
      onRecordAnswer?.(currentQuestion.id, "未配裝送出", false, 0);
      onClearAllSlots();
      if (currentIndex < totalQuestions - 1) {
        onNextQuestion();
      } else {
        setAlertMessage({
          type: 'warning',
          text: '本題已送出分數，即將結算成績！'
        });
      }
      return;
    }

    const expectedColorId = (finalColor === '' || finalColor === '無染色') ? '無' : finalColor;
    const constructedAnswer = (expectedColorId === '無')
      ? `${finalVerb} ${finalItem}`
      : `${finalVerb} ${expectedColorId}个${finalItem}`;

    validateAnswerString(constructedAnswer, true);
  };

  const downloadOutfitSouvenir = () => {
    playSound.success();

    const slotLabelMap: Record<SlotType, string> = {
      '頭部': '頭部配戴',
      '頸部': '頸部配件',
      '軀幹': '軀幹上著',
      '下身': '下半身裝',
      '腿部': '腿部襪飾',
      '腳部': '腳部鞋履'
    };

    // Collect active garments
    const equippedList: { slot: string; name: string; color: string; phonetic: string }[] = [];

    // Check equipped items
    Object.keys(equippedItems).forEach((slot) => {
      const equipped = equippedItems[slot as SlotType];
      if (equipped) {
        equippedList.push({
          slot: slotLabelMap[slot as SlotType] || slot,
          name: equipped.item.name,
          color: equipped.color.id,
          phonetic: equipped.item.phonetic
        });
      }
    });

    // Fallback if no items equipped (e.g. Phase 1 dropdown completed and no items are equipped on the doll yet)
    if (equippedList.length === 0) {
      const activeItem = itemDatabase.find(i => i.name === selectedItemName);
      if (activeItem) {
        equippedList.push({
          slot: slotLabelMap[activeItem.slot] || activeItem.slot,
          name: selectedItemName,
          color: selectedColorName,
          phonetic: activeItem.phonetic
        });
      }
    }

    // Generate rows inside SVG
    const rowHeight = 44;
    const baseGapY = 245;
    const listElements = equippedList.map((eq, i) => {
      const currentY = baseGapY + (i * rowHeight);
      const label = eq.color !== '無' ? `${eq.color}个 ${eq.name}` : eq.name;
      return `
        <!-- Item Row ${i} -->
        <g transform="translate(35, ${currentY})">
          <rect width="430" height="36" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1"/>
          <rect width="75" height="36" rx="8" fill="#0d9488"/>
          <text x="37.5" y="22" fill="#ffffff" font-family="'Inter', sans-serif" font-size="11" font-weight="bold" text-anchor="middle">${eq.slot}</text>
          
          <text x="90" y="22" fill="#0f172a" font-family="'Inter', sans-serif" font-size="13" font-weight="bold">${label}</text>
          <text x="250" y="22" fill="#b45309" font-family="monospace" font-size="11" font-weight="bold">${eq.phonetic}</text>
        </g>
      `;
    }).join('');

    const cardTitle = currentIndex === 0 ? '暖身例題' : `任務關卡 ${currentIndex}`;

    const svgContent = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 650" width="100%" height="100%">
  <defs>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&amp;display=swap');
      .main-title { font-family: 'Inter', system-ui, sans-serif; font-weight: 900; }
      .text-sm { font-family: 'Inter', system-ui, sans-serif; }
      .stamp-text { font-family: 'Inter', system-ui, sans-serif; font-weight: 700; }
    </style>
  </defs>

  <!-- Outer elegant card background -->
  <rect width="500" height="650" rx="24" fill="#0f172a" />
  
  <!-- Outer decorative border -->
  <rect x="12" y="12" width="476" height="626" rx="20" fill="none" stroke="#be123c" stroke-width="2" opacity="0.4"/>
  
  <!-- Inner White Canvas -->
  <rect x="18" y="18" width="464" height="614" rx="18" fill="#ffffff" />
  
  <!-- Header Pattern Banner (Hakka Indigo Inspired with Floral Motif dots) -->
  <path d="M 18 18 L 482 18 L 482 145 C 482 145, 340 160, 250 145 C 160 130, 18 145, 18 145 Z" fill="#0d9488" />
  
  <!-- Subtle circular floral patterns in banner background -->
  <circle cx="250" cy="-10" r="110" fill="#ccfbf1" opacity="0.1" />
  <circle cx="420" cy="50" r="40" fill="#ffffff" opacity="0.08" />
  <circle cx="80" cy="90" r="30" fill="#ffffff" opacity="0.08" />

  <!-- Dots decorative grid representing Hakka textile stitch -->
  <circle cx="50" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="70" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="90" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="410" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="430" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="450" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  
  <!-- Header Title -->
  <text x="250" y="68" fill="#ffffff" class="main-title" font-size="24" font-weight="900" text-anchor="middle" letter-spacing="3">客庄穿搭留念卡</text>
  <text x="250" y="94" fill="#ccfbf1" class="text-sm" font-size="11" font-weight="700" text-anchor="middle" letter-spacing="1">阿梅的穿搭珍藏</text>
  
  <!-- Gold Clearance Star Badge -->
  <g transform="translate(180, 108)">
    <rect width="140" height="22" rx="11" fill="#be123c" />
    <text x="70" y="15" fill="#ffffff" class="text-sm" font-size="10" font-weight="bold" text-anchor="middle">★ 完美通關認證 ★</text>
  </g>
  
  <!-- Context Scenario Info Block -->
  <g transform="translate(35, 165)">
    <rect width="430" height="52" rx="10" fill="#fffbeb" stroke="#fef3c7" stroke-width="1"/>
    <text x="15" y="20" fill="#b45309" class="text-sm" font-size="10" font-weight="bold">挑戰關卡：${cardTitle}</text>
    <text x="15" y="38" fill="#0f172a" class="text-sm" font-size="12" font-weight="bold">情境限制：${currentQuestion.restrictions}</text>
  </g>
  
  <!-- Table Header -->
  <text x="38" y="235" fill="#64748b" class="text-sm" font-size="10" font-weight="bold" letter-spacing="1">【穿搭配件細節清單】</text>
  
  <!-- Render elements -->
  ${listElements}
  
  <!-- Red Hakka Seal Stamp -->
  <g transform="translate(370, 505)">
    <rect width="75" height="75" rx="10" fill="none" stroke="#be123c" stroke-width="2.5" stroke-dasharray="3 2" />
    <rect x="3" y="3" width="69" height="69" rx="8" fill="none" stroke="#be123c" stroke-width="1" />
    <text x="37.5" y="32" fill="#be123c" class="stamp-text" font-size="15" font-weight="bold" text-anchor="middle" letter-spacing="2">客庄</text>
    <text x="37.5" y="55" fill="#be123c" class="stamp-text" font-size="15" font-weight="bold" text-anchor="middle" letter-spacing="2">時尚</text>
  </g>
  
  <!-- Footer metadata and branding -->
  <line x1="35" y1="495" x2="465" y2="495" stroke="#f1f5f9" stroke-width="2" />
  
  <text x="35" y="525" fill="#64748b" class="text-sm" font-size="11" font-weight="bold">探索客家生活智慧，展現自信風采！</text>
  <text x="35" y="545" fill="#94a3b8" class="text-sm" font-size="10">系統平台：客語穿搭大挑戰</text>
  <text x="35" y="565" fill="#94a3b8" class="text-sm" font-size="9" font-family="monospace">時間印記：${new Date().toLocaleDateString('zh-TW')} ${new Date().toLocaleTimeString('zh-TW')}</text>
  <text x="35" y="585" fill="#0d9488" class="text-sm" font-size="10" font-weight="bold">Google AI Studio Build 認證製作</text>
</svg>
`;

    // Trigger secure client-side download
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `客庄穿搭留念卡_${currentQuestion.id === 0 ? '暖身例題' : `關卡${currentQuestion.id}`}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (isAllCompleted) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 flex flex-col h-[540px] shadow-sm relative overflow-hidden justify-between">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-rose-500 to-teal-500" />
        
        <div className="flex flex-col items-center text-center gap-4 mt-4">
          <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center border border-amber-200 animate-bounce">
            <Trophy size={32} className="text-amber-500" />
          </div>
          
          <div className="space-y-1">
            <h2 className="text-xl font-extrabold bg-gradient-to-r from-amber-600 via-rose-500 to-teal-600 bg-clip-text text-transparent">
              🎉 恭喜滿分通關！
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              你已成功通過全部 10 關客庄經典穿搭考驗！
            </p>
          </div>

          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 w-full flex justify-around items-center gap-2">
            <div className="text-center">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">最終得分</span>
              <span className="text-2xl font-black text-amber-500 font-mono">100</span>
              <span className="text-xs font-bold text-slate-500 ml-0.5">分</span>
            </div>
            <div className="w-px h-8 bg-slate-200" />
            <div className="text-center">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">挑戰模式</span>
              <span className="text-xs font-extrabold text-teal-600 block mt-0.5">
                {gameMode === 'structured' ? '分段漸進模式' : '隨機綜合模式'}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            客家常民智慧體現於服裝與大自然互動的細節。不論是遮陽防晒、掃除防塵，或是極端風雪與運動防護，您已完美掌握客庄生活美學！
          </p>
        </div>

        <div className="space-y-2 mt-auto">
          <button
            onClick={onRestart}
            className="w-full py-3 bg-gradient-to-r from-teal-500 to-emerald-600 hover:opacity-95 text-white rounded-xl font-extrabold text-xs shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <RotateCcw size={13} />
            <span>重新抽題，再挑戰一局！</span>
          </button>
        </div>
      </div>
    );
  }

  const isBlueShirt = currentIndex < 5 
    ? (targetAnswer?.item === '藍衫') 
    : (blankType === 'item' ? (selectedItemName === '藍衫') : (targetAnswer?.item === '藍衫'));

  const isColorBlankEmpty = !selectedColorName || selectedColorName === '無';
  const isItemBlankEmpty = !selectedItemName || selectedItemName === '無' || selectedItemName === '';

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-4 flex flex-col h-[540px] shadow-sm relative overflow-hidden">
      {/* Decorative top border or Hakka red print bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-teal-500 to-amber-500" />

      {/* Header controls - Compact, extremely clear */}
      <div className="flex flex-col gap-2 mb-3 pb-2.5 border-b border-slate-100">
        <div className="flex justify-between items-center">
          <span className="text-[10px] bg-amber-500 text-white font-extrabold px-2 py-0.5 rounded-md uppercase tracking-wider">
            關卡 {currentIndex + 1}
          </span>

          {/* Large-Text Seasonal Restriction Badge moved here */}
          {currentQuestion?.restrictions && (
            <div className="shrink-0 flex justify-center">
              {currentQuestion.restrictions.includes('熱') ? (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-black text-xs bg-amber-50 text-amber-700 border border-amber-200 shadow-sm animate-pulse">
                  <span>☀️</span>
                  <span className="tracking-wide">夏天 / 熱</span>
                </div>
              ) : (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-black text-xs bg-sky-50 text-sky-750 border border-sky-200 shadow-sm animate-pulse">
                  <span>❄️</span>
                  <span className="tracking-wide">冬天 / 冷</span>
                </div>
              )}
            </div>
          )}

          <span className="text-[10px] font-mono text-slate-400 font-semibold">
            {currentIndex + 1} / {totalQuestions}
          </span>
        </div>
      </div>

      {/* Main interactive sentence block */}
      <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex-1 flex flex-col justify-between mb-3 min-h-[140px]">
        <div>
          <div className="bg-white rounded-xl p-3 border border-slate-100 shadow-sm">
            {/* Unified dynamic sentence builder with inline fields */}
            <div className="text-sm sm:text-base leading-relaxed text-slate-800 font-bold flex flex-wrap items-center gap-y-2.5 gap-x-1.5 font-serif py-1">
              {/* Verb display */}
              <span className="bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded-lg text-teal-800 text-xs sm:text-sm font-extrabold shadow-sm" title="動詞 (系統隨機決定)">
                {selectedVerb || targetAnswer?.verb || '著'}
              </span>

              {/* Color Block */}
              {!isBlueShirt && (
                <>
                  {currentIndex < 5 ? (
                    /* Phase 1: Fixed Color */
                    targetAnswer?.color && targetAnswer.color !== '無' && (
                      <span className="bg-amber-50 border border-amber-200 text-amber-700 px-2 py-0.5 rounded-lg text-xs sm:text-sm font-extrabold shadow-sm">
                        {targetAnswer.color}
                      </span>
                    )
                  ) : (
                    /* Phase 2: Color Blank or Fixed Color */
                    blankType === 'color' ? (
                      /* Color is Blank (styled in elegant purple with direct phonetic transcription and NO EMOJI) */
                      <span className="px-2.5 py-0.5 rounded-lg text-xs sm:text-sm font-black border-2 border-purple-950 bg-purple-100/85 text-purple-950 shadow-sm transition-all flex items-center gap-1 cursor-default">
                        {colorPhoneticMap[targetAnswer?.color || ''] || targetAnswer?.color || ''}
                      </span>
                    ) : (
                      /* Color is Fixed (regular slate styling) */
                      targetAnswer?.color && targetAnswer.color !== '無' && (
                        <span className="bg-slate-50 border border-slate-200 text-slate-700 px-2 py-0.5 rounded-lg text-xs sm:text-sm font-medium shadow-xs">
                          {targetAnswer.color}
                        </span>
                      )
                    )
                  )}

                  {/* Particle '个' */}
                  {targetAnswer?.color && targetAnswer.color !== '無' && (
                    <span className="text-slate-400 text-xs sm:text-sm font-bold font-sans">个</span>
                  )}
                </>
              )}

              {/* Item Slot */}
              {currentIndex < 5 ? (
                /* Phase 1: Fixed Item */
                <span className="bg-blue-50 border border-blue-200 text-blue-700 px-2 py-0.5 rounded-lg text-xs sm:text-sm font-extrabold shadow-sm">
                  {targetAnswer?.item || '短衫'}
                </span>
              ) : (
                /* Phase 2: Item Blank or Fixed Item */
                blankType === 'item' ? (
                  /* Item is Blank (styled in elegant purple with direct phonetic transcription and NO EMOJI) */
                  <span className="px-2.5 py-0.5 rounded-lg text-xs sm:text-sm font-black border-2 border-purple-950 bg-purple-100/85 text-purple-950 shadow-sm transition-all flex items-center gap-1 cursor-default">
                    {itemDatabase.find(i => i.name === targetAnswer?.item)?.phonetic || targetAnswer?.item || ''}
                  </span>
                ) : (
                  /* Item is Fixed (regular slate styling) */
                  <span className="bg-slate-50 border border-slate-200 text-slate-700 px-2 py-0.5 rounded-lg text-xs sm:text-sm font-medium shadow-xs">
                    {targetAnswer?.item || '短衫'}
                  </span>
                )
              )}

              {/* Narrative clause directly following the garment */}
              <span className="text-slate-700 font-sans text-xs sm:text-sm font-medium border-b border-dashed border-slate-200 px-0.5">
                {currentQuestion.narrative}
              </span>
            </div>
          </div>
        </div>

        {/* Helper guide for fill-in-the-blank levels */}
        {currentIndex >= 5 && (
          <>
            {((blankType === 'color' && isColorBlankEmpty) || (blankType === 'item' && isItemBlankEmpty)) && (
              <motion.div
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="text-[11px] text-purple-900 font-extrabold bg-purple-50/90 rounded-lg py-1.5 px-3 border border-purple-250 mt-2 animate-fade-in flex items-center gap-1.5 shadow-xs"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-600 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-900"></span>
                </span>
                <span>現在需要點擊右側衣櫃或染色工坊，來填入深紫色空格中的{blankType === 'color' ? '顏色' : '衣物'}喔！</span>
              </motion.div>
            )}
            <div className="text-[10px] text-teal-600 font-bold bg-teal-50/50 rounded-lg py-1 px-2 border border-teal-100/30 mt-2 animate-fade-in flex items-center gap-1">
              <span className="animate-bounce">💡</span>
              <span>客莊提示：點擊右側【客庄衣櫃】選配衣服與顏色，答案會自動填入空格中！</span>
            </div>
          </>
        )}

        {/* Verification feedback box */}
        {alertMessage.text && (
          <div
            className={`p-3 rounded-xl border flex items-start gap-2.5 mt-2 animate-fade-in ${
              alertMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : alertMessage.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : 'bg-amber-50 border-amber-200 text-amber-800'
            }`}
          >
            {alertMessage.type === 'success' ? (
              <CheckCircle2 size={18} className="text-emerald-600 shrink-0 mt-0.5" />
            ) : alertMessage.type === 'error' ? (
              <AlertTriangle size={18} className="text-rose-600 shrink-0 mt-0.5" />
            ) : (
              <HelpCircle size={18} className="text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="text-xs leading-relaxed font-semibold flex-1">
              <div>{alertMessage.text}</div>
              {/* Removed the old nested button */}
            </div>
          </div>
        )}
      </div>

      {/* Bottom control row */}
      <div className="space-y-3 mt-auto">
        {/* Countdown To Next Question Banner */}
        {countdownToNext !== null && (
          <div className="bg-slate-900 text-teal-100 p-3 rounded-xl border border-teal-500/20 shadow-md animate-fade-in flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping shrink-0" />
              <p className="text-xs font-bold">
                ⏱️ 系統將在 <strong className="text-amber-300 font-mono text-sm">{countdownToNext}</strong> 秒後自動進入下一關...
              </p>
            </div>
            {currentIndex < totalQuestions - 1 ? (
              <button
                onClick={() => {
                  playSound.click();
                  setCountdownToNext(null);
                  onNextQuestion();
                }}
                className="px-2.5 py-1 bg-teal-600 hover:bg-teal-500 text-white text-[11px] font-black rounded-lg transition-all flex items-center gap-0.5 shadow shrink-0 cursor-pointer"
              >
                <span>不等待，直接下一關</span>
                <ChevronRight size={12} />
              </button>
            ) : (
              <span className="text-[10px] text-amber-300 font-extrabold animate-pulse">即將結算成績...</span>
            )}
          </div>
        )}

        {/* If already submitted but not perfectly correct, offer "Proceed to Next Question with current score" */}
        {questionScores[currentQuestion.id] !== undefined && !questionResults[currentQuestion.id] && countdownToNext === null && (
          <button
            onClick={handleProceedWithCurrentScore}
            className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-xl font-black shadow-md transition-all duration-150 flex items-center justify-center gap-1.5 cursor-pointer text-xs transform hover:scale-[1.01] animate-fade-in border border-amber-400/20"
          >
            <ChevronRight size={14} />
            <span>進入下一關</span>
          </button>
        )}

        {/* Verification action button */}
        {countdownToNext === null && !(currentQuestion.id in questionResults) && (
          <button
            onClick={handleDropdownSubmit}
            className="w-full py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:opacity-90 text-white rounded-xl font-bold shadow-md transition duration-150 flex items-center justify-center gap-1.5 cursor-pointer text-sm"
          >
            <CheckCircle2 size={16} />
            <span>送出此搭配驗證答案</span>
          </button>
        )}

        {/* Control Reset & Skip Buttons */}
        {countdownToNext === null && !(currentQuestion.id in questionResults) && (
          <div className="flex justify-between items-center gap-3">
            <button
              onClick={handleManualReset}
              className="w-1/2 py-2 border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-800 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer"
              title="清空裝扮重配"
            >
              <RotateCcw size={13} />
              <span>重新配裝</span>
            </button>

            <button
              onClick={handleSkipQuestion}
              className="w-1/2 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-600 hover:text-slate-900 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer"
              title="跳過此題"
            >
              <ChevronRight size={13} />
              <span>跳過此題</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
