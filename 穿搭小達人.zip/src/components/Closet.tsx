import React, { useState, useEffect } from 'react';
import { ClothingItem, ColorType, SlotType, Question } from '../types';
import { items as defaultItemDatabase, colors as defaultColorPalette } from '../data/questions';
import { playSound } from '../utils/audio';
import { Shirt } from 'lucide-react';

interface ClosetProps {
  onEquipItem: (item: ClothingItem, color: ColorType) => void;
  selectedSlot: SlotType | null;
  equippedItems: Record<SlotType, { item: ClothingItem; color: ColorType } | null>;
  currentQuestion?: Question;
  itemDatabase?: ClothingItem[];
  colorPalette?: ColorType[];
  currentIndex?: number;
}

const getItemEmoji = (itemName: string): string => {
  switch (itemName) {
    case '帽仔': return '🧢';
    case '泅水帽': return '🏊';
    case '頸圍仔': return '🧣';
    case '藍衫': return '👚';
    case '短衫': return '👕';
    case '羽絨衫': return '🧥';
    case '膨線衫': return '🧶';
    case '短褲': return '🩳';
    case '長褲': return '👖';
    case '裙': return '👗';
    case '膝頭落仔': return '🩹';
    case '鞋': return '👟';
    case '水靴筒': return '👢';
    default: return '👕';
  }
};

export const Closet: React.FC<ClosetProps> = ({ 
  onEquipItem, 
  selectedSlot, 
  equippedItems, 
  currentQuestion,
  itemDatabase = defaultItemDatabase,
  colorPalette = defaultColorPalette,
  currentIndex
}) => {
  const [filterSlot, setFilterSlot] = useState<string>('全部');
  const [selectedItem, setSelectedItem] = useState<ClothingItem | null>(null);
  const [selectedColor, setSelectedColor] = useState<ColorType>(colorPalette[0]); // Default to No Color

  const categories = ['全部', '上衣', '褲裙', '鞋襪', '配件'];

  // Automatically sync selected item & color with slot focus
  useEffect(() => {
    if (selectedSlot) {
      const equipped = equippedItems[selectedSlot];
      if (equipped) {
        setSelectedItem(equipped.item);
        setSelectedColor(equipped.color);
      } else {
        setSelectedItem(null);
      }
    }
  }, [selectedSlot, equippedItems]);

  // Filter items based on current category selection or slot focus
  const filteredItems = itemDatabase.filter((item) => {
    if (selectedSlot && item.slot !== selectedSlot) {
      return false;
    }

    if (!selectedSlot) {
      if (filterSlot === '全部') return true;
      if (filterSlot === '上衣') return item.slot === '軀幹';
      if (filterSlot === '褲裙') return item.slot === '下身';
      if (filterSlot === '鞋襪') return item.slot === '腳部';
      if (filterSlot === '配件') return ['頭部', '頸部', '腿部'].includes(item.slot);
    }
    return true;
  });

  const handleItemSelect = (item: ClothingItem) => {
    playSound.click();
    setSelectedItem(item);
    
    // Auto equip! If "藍衫", force "無" color. Otherwise use selectedColor.
    const actualColor = item.name === '藍衫' ? colorPalette[0] : selectedColor;
    if (item.name === '藍衫') {
      setSelectedColor(colorPalette[0]);
    }
    
    onEquipItem(item, actualColor);
  };

  const handleColorSelect = (color: ColorType) => {
    playSound.click();
    setSelectedColor(color);

    // Auto dye and equip currently active item or currently equipped item of selected slot!
    const activeEquipped = selectedSlot ? equippedItems[selectedSlot] : null;
    const targetItem = selectedItem || activeEquipped?.item;

    if (targetItem) {
      if (targetItem.name === '藍衫') {
        return; // Skip dyeing for 藍衫
      }
      onEquipItem(targetItem, color);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-4 flex flex-col h-[540px] shadow-sm select-none">
      <div className="flex justify-between items-center mb-3 shrink-0">
        <div>
          <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5">
            <Shirt className="text-teal-600" size={16} />
            <span>客庄衣櫃與染工坊</span>
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">點選衣服或染色即可即時幫紙娃娃穿搭：</p>
        </div>
        {/* Seasonal badges removed */}
      </div>

      {/* 1. Dye Workshop Section */}
      <div className="mb-4 shrink-0">
        <h4 className="text-xs font-black text-teal-700 mb-1.5 flex items-center gap-1">
          <span className="text-xs">🎨</span>
          <span>【 染工坊 】</span>
        </h4>
        <div className="flex flex-wrap gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100">
          {colorPalette.filter(col => col.id !== '無').map((col) => {
            const isColorSelected = selectedColor.id === col.id;
            const isRedPattern = col.id === '紅色花圖案';

            return (
              <button
                key={col.id}
                onClick={() => handleColorSelect(col)}
                className={`relative w-8 h-8 rounded-full border transition-all duration-200 cursor-pointer flex items-center justify-center ${
                  isColorSelected
                    ? 'ring-2 ring-teal-500 scale-110 shadow-md border-teal-500 z-10'
                    : 'border-slate-300 hover:scale-105'
                }`}
                style={{
                  backgroundColor: isRedPattern ? '#ec4899' : col.hex,
                  backgroundImage: isRedPattern
                    ? 'radial-gradient(#fbcfe8 2px, transparent 2px)'
                    : 'none',
                  backgroundSize: isRedPattern ? '6px 6px' : 'none',
                }}
                title={col.phonetic ? `${col.phonetic} (${col.translation})` : col.name}
              >
                {isColorSelected ? (
                  <div
                    className="w-2.5 h-2.5 rounded-full ring-1 ring-white"
                    style={{ backgroundColor: col.textHex }}
                  />
                ) : null}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Wardrobe Section */}
      <div className="flex flex-col flex-1 min-h-0 border-t border-slate-100 pt-3">
        <h4 className="text-xs font-black text-teal-700 mb-2 flex items-center gap-1">
          <span className="text-xs">👕</span>
          <span>【 客庄衣櫃 】</span>
        </h4>

        {/* Category Tabs */}
        {!selectedSlot ? (
          <div className="flex border-b border-slate-100 mb-2.5 overflow-x-auto scrollbar-none py-0.5 gap-1.5 shrink-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => { playSound.click(); setFilterSlot(cat); }}
                className={`px-3 py-1 text-xs rounded-full border transition-all whitespace-nowrap cursor-pointer font-bold ${
                  filterSlot === cat
                    ? 'border-teal-500 bg-teal-500 text-white shadow-sm'
                    : 'border-slate-100 bg-slate-50 text-slate-500 hover:bg-slate-100 hover:text-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        ) : (
          <div className="bg-teal-50 border border-teal-200 text-teal-800 text-[10px] py-1 px-2.5 rounded-lg font-bold mb-2.5 shrink-0 flex justify-between items-center">
            <span>✨ 正在為「{selectedSlot}」部位挑選衣物</span>
            <span className="text-[9px] bg-teal-100 px-1.5 py-0.5 rounded text-teal-700 font-mono">Slot Focus</span>
          </div>
        )}

        {/* Item grid */}
        <div className="grid grid-cols-2 gap-2 overflow-y-auto pr-1 flex-1 scrollbar-thin">
          {filteredItems.map((item) => {
            const equipped = equippedItems[item.slot];
            const isEquippedThisItem = equipped?.item.name === item.name;
            const isSelected = selectedItem?.name === item.name;

            // Highlight border if equipped or selected
            const highlightClass = isEquippedThisItem
              ? 'border-emerald-500 bg-emerald-50/40 text-emerald-800 ring-2 ring-emerald-100 font-extrabold scale-[0.98]'
              : isSelected
              ? 'border-teal-500 bg-teal-50/20 text-teal-800 ring-1 ring-teal-100 font-extrabold'
              : 'border-slate-100 bg-slate-50 text-slate-600 hover:bg-slate-100/80 hover:border-slate-200 font-bold';

            return (
              <button
                key={item.name}
                onClick={() => handleItemSelect(item)}
                className={`py-2 px-1.5 rounded-xl border text-center transition-all duration-150 flex flex-col items-center justify-center gap-1.5 relative cursor-pointer group ${highlightClass}`}
              >
                {isEquippedThisItem && (
                  <span className="absolute top-1 right-1 bg-emerald-500 text-white text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold shadow-sm">
                    ✓
                  </span>
                )}
                <span className="text-2xl group-hover:scale-110 transition-transform duration-150">
                  {getItemEmoji(item.name)}
                </span>
                <span className="text-xs font-bold">{item.name}</span>
                <span className="text-[9px] text-slate-400 font-normal">
                  {item.slot}
                </span>
              </button>
            );
          })}
        </div>

        {/* Quick Help Guide */}
        <div className="text-[9px] text-slate-400 mt-2 text-center font-semibold shrink-0">
          💡 點擊衣服直接穿上，選上方染色即時變更色彩！
        </div>
      </div>
    </div>
  );
};
