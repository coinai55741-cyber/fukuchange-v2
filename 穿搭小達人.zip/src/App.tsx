import React, { useState, useEffect } from 'react';
import html2canvas from 'html2canvas';
import { AnimatePresence, motion } from 'motion/react';
import { ClothingItem, ColorType, GamePhase, SlotType, Question } from './types';
import { questions, items, colors } from './data/questions';
import { PaperDoll } from './components/PaperDoll';
import { Closet } from './components/Closet';
import { MissionCard } from './components/MissionCard';
import { LearnModal } from './components/LearnModal';
import { playSound } from './utils/audio';
import { BookOpen, Trophy, Sparkles, AlertCircle, RefreshCw, Star, Timer, Camera, RotateCcw, Clock, Download, FileSpreadsheet, Wrench, Terminal, CheckCircle, Cpu, ShieldAlert, Upload, Trash2, Database, AlertTriangle } from 'lucide-react';

const TUTORIAL_STEPS = [
  {
    title: "🌸 歡迎來到客庄穿搭教學導覽！",
    subtitle: "",
    desc: "本遊戲旨在帶領玩家體驗客庄日常情境、認識傳統服飾，並學習常民智慧與客語配裝。我們將在 1 分鐘內帶您熟悉核心介面與操作，一起來玩吧！",
    tip: "本教學進行時，遊戲倒數計時會完全暫停，您可以放心學習與閱讀！",
    highlightId: null,
  },
  {
    title: "🎯 任務卡與客語文法填空",
    subtitle: "",
    desc: "這是您的主要任務目標。在這裡您會看到當前關卡的生活或風俗情境（例如：大掃除、婚宴、防曬等）與特定穿衣避諱限制。請仔細閱讀，並在下方挑選最合適的客語字詞填空，來組成正確的客家穿戴造句！",
    tip: "小撇步：只要您在紙娃娃或衣櫃中穿上正確的服裝，系統會聰明地自動為您填入答案喔！選好後按下「檢查答案」來完成挑戰！",
    highlightId: "tutorial-mission-card",
  },
  {
    title: "👕 客庄紙娃娃與部位點選",
    subtitle: "",
    desc: "中央展示當前角色的穿搭外觀。您可以點擊人像周圍對應的「頭部、頸部、軀幹、下身、腿部、腳部」部位插槽按鈕。點選後，右側衣櫃會立刻開啟對應的服飾選擇。您也可以在這裡一鍵切換阿弟與阿妹角色！",
    tip: "只要點擊部位，就能決定您要為角色穿戴哪一個品項。若想脫下某個部位，可點擊部位旁的「清除/脫下」按鈕！",
    highlightId: "tutorial-paper-doll",
  },
  {
    title: "🎨 繽紛衣櫃與客庄染色工坊",
    subtitle: "",
    desc: "右側為衣櫃區，包含 13 種經典客庄服飾與配件。當您點選一個身體部位後，點選喜歡的衣服就能一鍵穿戴！最有趣的是：您可以在穿戴前點選下方的「7 種客庄經典色彩」為衣服染色，創造出色彩斑斕的客家穿搭！",
    tip: "色彩包含：柑仔色、大藍/藍衫色、烏色、大紅色等。留意題目要求的染色限制，別染錯色囉！",
    highlightId: "tutorial-closet",
  },
  {
    title: "🗺️ 闖關地圖與即時文化檢討",
    subtitle: "",
    desc: "頂部會顯示 10 個關卡的闖關地圖。前 5 關為單空欄（僅需填色），後 5 關為雙空欄（填色與衣服）。每題分值 10 分，答錯時系統會即時彈出細膩的「文化避諱檢討說明」（如：賞螢不穿亮色），加深學習體驗！",
    tip: "當累積到 100 分時，就能解鎖客庄穿搭大師的最高成就！快來穿出最地道、最安全的客庄美學吧！",
    highlightId: "tutorial-progress-bar",
  }
];

export default function App() {
  const [gameMode, setGameMode] = useState<'structured' | 'random'>('structured');
  const [currentView, setCurrentView] = useState<'game' | 'learn'>('game');
  
  const [currentQuestions, setCurrentQuestions] = useState<Question[]>(questions);
  const [currentItems, setCurrentItems] = useState<ClothingItem[]>(items);
  const [currentColors, setCurrentColors] = useState<ColorType[]>(colors);

  const [activeImportTab, setActiveImportTab] = useState<'items' | 'colors' | 'questions'>('items');
  const [dragActiveType, setDragActiveType] = useState<'items' | 'colors' | 'questions' | null>(null);

  const [validationReport, setValidationReport] = useState<{
    type: 'items' | 'colors' | 'questions' | null;
    status: 'idle' | 'success' | 'error' | 'warning';
    fileName: string;
    errors: string[];
    warnings: string[];
    recordsImportedCount: number;
  }>({
    type: null,
    status: 'idle',
    fileName: '',
    errors: [],
    warnings: [],
    recordsImportedCount: 0
  });

  const getActiveQuestions = (customQuestions: Question[] = currentQuestions) => {
    // Pool 1 (IDs 1-7) for Phase 1 (indices 0-4), Pool 2 (IDs 8-20) for Phase 2 (indices 5-9)
    const pool1 = customQuestions.filter(q => q.id <= 7);
    const pool2 = customQuestions.filter(q => q.id >= 8);
    
    const shuffledPool1 = [...pool1].sort(() => 0.5 - Math.random()).slice(0, 5);
    const shuffledPool2 = [...pool2].sort(() => 0.5 - Math.random()).slice(0, 5);
    
    return [...shuffledPool1, ...shuffledPool2];
  };

  const [activeQuestions, setActiveQuestions] = useState<Question[]>(() => getActiveQuestions(questions));
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [gamePhase, setGamePhase] = useState<GamePhase>(1);
  const [selectedSlot, setSelectedSlot] = useState<SlotType | null>(null);
  const [gender, setGender] = useState<'阿弟' | '阿妹'>('阿妹');
  const [isLearnModalOpen, setIsLearnModalOpen] = useState<boolean>(false);
  const [questionResults, setQuestionResults] = useState<Record<number, boolean>>({});
  const [questionScores, setQuestionScores] = useState<Record<number, number>>({});
  const [lastSubmittedAnswers, setLastSubmittedAnswers] = useState<Record<number, { text: string; isCorrect: boolean }>>({});
  const [isGameStarted, setIsGameStarted] = useState<boolean>(false);
  const [timeElapsedMs, setTimeElapsedMs] = useState<number>(0);
  const [showResultModal, setShowResultModal] = useState<boolean>(false);
  
  // States for smooth, premium Hakka-themed stage transition overlay
  const [showTransitionOverlay, setShowTransitionOverlay] = useState<boolean>(false);
  const [transitionStageNum, setTransitionStageNum] = useState<number>(1);
  const [transitionTitle, setTransitionTitle] = useState<string>('');

  // States for game tutorial guide onboarding overlay
  const [isTutorialActive, setIsTutorialActive] = useState<boolean>(false);
  const [tutorialStep, setTutorialStep] = useState<number>(0);
  const [needTutorial, setNeedTutorial] = useState<boolean>(true);

  // Helper to format time to MM:SS.CC (Minutes, Seconds, Centiseconds)
  const formatTime = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    const cents = Math.floor((ms % 1000) / 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${cents.toString().padStart(2, '0')}`;
  };

  // CSV download function for clothing items (Engineer-ready format)
  const downloadItemsCSV = () => {
    const headers = ["name", "slot", "phonetic", "translation", "desc", "verb", "tags"];
    const rows = currentItems.map(item => [
      item.name,
      item.slot,
      item.phonetic,
      item.translation,
      item.desc,
      item.verb,
      item.tags.join(';')
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'hakka_clothing_items_db.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // CSV download function for traditional colors (Engineer-ready format)
  const downloadColorsCSV = () => {
    const headers = ["id", "name", "hex", "textHex", "isPattern"];
    const rows = currentColors.map(c => [
      c.id,
      c.name,
      c.hex,
      c.textHex,
      c.isPattern ? "true" : "false"
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'hakka_clothing_colors_db.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // CSV download function for levels and questions (Engineer-ready format)
  const downloadQuestionsCSV = () => {
    const headers = ["id", "restrictions", "narrative", "hint", "allowedAnswers"];
    const rows = currentQuestions.map(q => [
      q.id,
      q.restrictions,
      q.narrative,
      q.hint,
      q.allowedAnswers.join(';')
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'hakka_game_questions_db.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const initGame = (mode: 'structured' | 'random' = 'structured', customQuestions = currentQuestions) => {
    const drawn = getActiveQuestions(customQuestions);
    setActiveQuestions(drawn);
    setCurrentQuestionIndex(0);
    setQuestionResults({});
    setQuestionScores({});
    setLastSubmittedAnswers({});
    setTimeElapsedMs(0); // Initialize positive stopwatch
    setShowResultModal(false);
    setLastEquipped(null);
    handleClearAllSlots();
    if (mode === 'structured') {
      setGamePhase(1);
    }
  };

  // RFC 4180 standard CSV parser supporting commas/newlines inside quotes
  const parseCSV = (text: string): string[][] => {
    const result: string[][] = [];
    let row: string[] = [];
    let cell = '';
    let insideQuote = false;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const nextChar = text[i + 1];

      if (char === '"') {
        if (insideQuote && nextChar === '"') {
          cell += '"';
          i++;
        } else {
          insideQuote = !insideQuote;
        }
      } else if (char === ',' && !insideQuote) {
        row.push(cell.trim());
        cell = '';
      } else if ((char === '\r' || char === '\n') && !insideQuote) {
        row.push(cell.trim());
        cell = '';
        if (row.length > 0 && (row.length > 1 || row[0] !== '')) {
          result.push(row);
        }
        row = [];
        if (char === '\r' && nextChar === '\n') {
          i++;
        }
      } else {
        cell += char;
      }
    }

    if (cell !== '' || row.length > 0) {
      row.push(cell.trim());
      result.push(row);
    }

    // Remove UTF-8 BOM if present
    if (result.length > 0 && result[0].length > 0) {
      result[0][0] = result[0][0].replace(/^\uFEFF/, '');
    }

    return result;
  };

  // CSV Custom Data Import & Validation Handler
  const handleImportCSV = (type: 'items' | 'colors' | 'questions', fileContent: string, fileName: string) => {
    try {
      const parsed = parseCSV(fileContent);
      if (parsed.length === 0) {
        setValidationReport({
          type,
          status: 'error',
          fileName,
          errors: ["CSV 檔案內容為空，或是解析時發生未知錯誤。"],
          warnings: [],
          recordsImportedCount: 0
        });
        playSound.fail();
        return;
      }

      const headers = parsed[0].map(h => h.trim().toLowerCase());
      const rows = parsed.slice(1);

      const errors: string[] = [];
      const warnings: string[] = [];

      if (type === 'items') {
        const required = ["name", "slot", "phonetic", "translation", "desc", "verb", "tags"];
        const missing = required.filter(r => !headers.includes(r));
        if (missing.length > 0) {
          setValidationReport({
            type,
            status: 'error',
            fileName,
            errors: [`CSV 缺少必要的表頭：${missing.join(', ')}。請確認英文大小寫是否正確。`],
            warnings: [],
            recordsImportedCount: 0
          });
          playSound.fail();
          return;
        }

        const nameIdx = headers.indexOf("name");
        const slotIdx = headers.indexOf("slot");
        const phoneticIdx = headers.indexOf("phonetic");
        const translationIdx = headers.indexOf("translation");
        const descIdx = headers.indexOf("desc");
        const verbIdx = headers.indexOf("verb");
        const tagsIdx = headers.indexOf("tags");

        const newItems: ClothingItem[] = [];

        rows.forEach((row, index) => {
          const rowNum = index + 2;
          if (row.length < required.length) {
            errors.push(`第 ${rowNum} 行：資料列長度不足，請確保包含所有欄位。`);
            return;
          }

          const name = row[nameIdx]?.trim() || '';
          const slot = row[slotIdx]?.trim() || '';
          const phonetic = row[phoneticIdx]?.trim() || '';
          const translation = row[translationIdx]?.trim() || '';
          const desc = row[descIdx]?.trim() || '';
          const verb = row[verbIdx]?.trim() || '';
          const tagsStr = row[tagsIdx]?.trim() || '';

          if (!name) {
            errors.push(`第 ${rowNum} 行："name" (服飾名稱) 不能為空。`);
          }

          const validSlots = ['頭部', '頸部', '軀幹', '下身', '腿部', '腳部'];
          if (!validSlots.includes(slot)) {
            errors.push(`第 ${rowNum} 行：無效的部位標籤 "${slot}"。必須為以下之一：${validSlots.join(', ')}`);
          }

          const validVerbs = ['著', '戴'];
          if (!validVerbs.includes(verb)) {
            errors.push(`第 ${rowNum} 行：無效的客語穿著動詞 "${verb}"。必須為：著 (穿衣/褲/鞋) 或 戴 (戴帽/配件)`);
          }

          const tags = tagsStr ? tagsStr.split(';').map(t => t.trim()).filter(Boolean) : [];

          if (errors.length === 0) {
            newItems.push({
              name,
              slot: slot as SlotType,
              phonetic,
              translation,
              desc,
              verb: verb as '著' | '戴',
              tags
            });
          }
        });

        if (errors.length > 0) {
          setValidationReport({
            type,
            status: 'error',
            fileName,
            errors,
            warnings,
            recordsImportedCount: 0
          });
          playSound.fail();
          return;
        }

        // Apply dynamically updated items
        setCurrentItems(newItems);
        initGame(gameMode, currentQuestions);
        setValidationReport({
          type,
          status: 'success',
          fileName,
          errors: [],
          warnings: [],
          recordsImportedCount: newItems.length
        });
        playSound.success();

      } else if (type === 'colors') {
        const required = ["id", "name", "hex", "texthex"];
        const missing = required.filter(r => !headers.includes(r));
        if (missing.length > 0) {
          setValidationReport({
            type,
            status: 'error',
            fileName,
            errors: [`CSV 缺少必要的色彩表頭：${missing.join(', ')}。請確認英文大小寫。`],
            warnings: [],
            recordsImportedCount: 0
          });
          playSound.fail();
          return;
        }

        const idIdx = headers.indexOf("id");
        const nameIdx = headers.indexOf("name");
        const hexIdx = headers.indexOf("hex");
        const textHexIdx = headers.indexOf("texthex");
        const isPatternIdx = headers.indexOf("ispattern");

        const newColors: ColorType[] = [];

        rows.forEach((row, index) => {
          const rowNum = index + 2;
          if (row.length < required.length) {
            errors.push(`第 ${rowNum} 行：資料列長度不足。`);
            return;
          }

          const id = row[idIdx]?.trim() || '';
          const name = row[nameIdx]?.trim() || '';
          const hex = row[hexIdx]?.trim() || '';
          const textHex = row[textHexIdx]?.trim() || '';
          const isPatternVal = row[isPatternIdx]?.trim()?.toLowerCase();
          const isPattern = isPatternVal === 'true' || isPatternVal === '1';

          if (!id) {
            errors.push(`第 ${rowNum} 行："id" (色彩客語唯一碼) 不能為空。`);
          }
          if (!name) {
            errors.push(`第 ${rowNum} 行："name" (中文俗稱與色彩翻譯) 不能為空。`);
          }
          if (!hex || !hex.startsWith('#')) {
            warnings.push(`第 ${rowNum} 行：色彩網頁 Hex 碼 "${hex}" 似乎未以 "#" 開頭，建議使用標準格式 (e.g., #1E3A8A)。`);
          }
          if (textHex && !textHex.startsWith('#')) {
            warnings.push(`第 ${rowNum} 行：文字覆蓋色 Hex 碼 "${textHex}" 似乎未以 "#" 開頭。`);
          }

          if (errors.length === 0) {
            newColors.push({
              id,
              name,
              hex,
              textHex,
              isPattern: isPattern || undefined
            });
          }
        });

        if (errors.length > 0) {
          setValidationReport({
            type,
            status: 'error',
            fileName,
            errors,
            warnings,
            recordsImportedCount: 0
          });
          playSound.fail();
          return;
        }

        // Apply updated colors
        setCurrentColors(newColors);
        initGame(gameMode, currentQuestions);
        setValidationReport({
          type,
          status: warnings.length > 0 ? 'warning' : 'success',
          fileName,
          errors: [],
          warnings,
          recordsImportedCount: newColors.length
        });
        playSound.success();

      } else if (type === 'questions') {
        const required = ["id", "restrictions", "narrative", "hint", "allowedanswers"];
        const missing = required.filter(r => !headers.includes(r));
        if (missing.length > 0) {
          setValidationReport({
            type,
            status: 'error',
            fileName,
            errors: [`CSV 缺少必要的關卡表頭：${missing.join(', ')}。`],
            warnings: [],
            recordsImportedCount: 0
          });
          playSound.fail();
          return;
        }

        const idIdx = headers.indexOf("id");
        const restrictionsIdx = headers.indexOf("restrictions");
        const narrativeIdx = headers.indexOf("narrative");
        const hintIdx = headers.indexOf("hint");
        const allowedAnswersIdx = headers.indexOf("allowedanswers");

        const newQuestions: Question[] = [];

        rows.forEach((row, index) => {
          const rowNum = index + 2;
          if (row.length < required.length) {
            errors.push(`第 ${rowNum} 行：資料列長度不足。`);
            return;
          }

          const idStr = row[idIdx]?.trim() || '';
          const restrictions = row[restrictionsIdx]?.trim() || '';
          const narrative = row[narrativeIdx]?.trim() || '';
          const hint = row[hintIdx]?.trim() || '';
          const allowedAnswersStr = row[allowedAnswersIdx]?.trim() || '';

          const id = parseInt(idStr, 10);
          if (isNaN(id) || id <= 0) {
            errors.push(`第 ${rowNum} 行："id" 關卡編號必須為正整數。`);
          }

          if (!restrictions) {
            errors.push(`第 ${rowNum} 行："restrictions" (情境節氣限制) 不能為空。`);
          }
          if (!narrative) {
            errors.push(`第 ${rowNum} 行："narrative" (情境引導語) 不能為空。`);
          }
          if (!hint) {
            errors.push(`第 ${rowNum} 行："hint" (闖關提示) 不能為空。`);
          }
          if (!allowedAnswersStr) {
            errors.push(`第 ${rowNum} 行："allowedAnswers" (可接受的答案組合) 不能為空。`);
          }

          const allowedAnswers = allowedAnswersStr ? allowedAnswersStr.split(';').map(a => a.trim()).filter(Boolean) : [];
          if (allowedAnswers.length === 0) {
            errors.push(`第 ${rowNum} 行：必須在 "allowedAnswers" 中定義至少一組答案 (以分號隔開)。`);
          }

          // Cross-reference evaluation (against currently active clothing & colors)
          allowedAnswers.forEach(ans => {
            const parts = ans.split(' ');
            const verb = parts[0];
            const clothingDescription = parts.slice(1).join(' ');

            if (verb !== '著' && verb !== '戴') {
              warnings.push(`第 ${rowNum} 行：答案 "${ans}" 的動詞 "${verb}" 似乎不為 "著" 或 "戴"。`);
            }

            if (!clothingDescription) {
              warnings.push(`第 ${rowNum} 行：答案 "${ans}" 缺少衣服配件描述部分。`);
              return;
            }

            let colorName = '無';
            let itemName = clothingDescription;

            if (clothingDescription.includes('个')) {
              const subparts = clothingDescription.split('个');
              colorName = subparts[0];
              itemName = subparts[1];
            }

            // Cross-check item
            const foundItem = currentItems.find(i => i.name === itemName);
            if (!foundItem) {
              warnings.push(`第 ${rowNum} 行：正確解答中的服飾配件名稱 "${itemName}" 並不存在於目前的「服飾配件數據庫」中，若未同步匯入，玩家將無法在遊戲內配對。`);
            } else {
              if (foundItem.verb !== verb) {
                warnings.push(`第 ${rowNum} 行：正確解答中的動詞為 "${verb}"，但在服飾庫中 "${itemName}" 定義的動詞為 "${foundItem.verb}"。`);
              }
            }

            // Cross-check color
            if (colorName !== '無') {
              const foundColor = currentColors.find(c => c.id === colorName);
              if (!foundColor) {
                warnings.push(`第 ${rowNum} 行：正確解答中使用的色彩 "${colorName}" 並不存在於目前的「傳統色彩數據庫」中，可能導致檢驗配對失敗。`);
              }
            }
          });

          if (errors.length === 0) {
            newQuestions.push({
              id,
              restrictions,
              narrative,
              hint,
              allowedAnswers
            });
          }
        });

        if (errors.length > 0) {
          setValidationReport({
            type,
            status: 'error',
            fileName,
            errors,
            warnings,
            recordsImportedCount: 0
          });
          playSound.fail();
          return;
        }

        // Apply dynamic questions and restart game
        setCurrentQuestions(newQuestions);
        initGame(gameMode, newQuestions);
        setValidationReport({
          type,
          status: warnings.length > 0 ? 'warning' : 'success',
          fileName,
          errors: [],
          warnings,
          recordsImportedCount: newQuestions.length
        });
        playSound.success();
      }

    } catch (err: any) {
      setValidationReport({
        type,
        status: 'error',
        fileName,
        errors: [`CSV 檔案解析時發生未預期錯誤：${err.message || err}`],
        warnings: [],
        recordsImportedCount: 0
      });
      playSound.fail();
    }
  };

  // Restore datasets back to original default presets
  const handleRestoreDefaults = () => {
    playSound.success();
    setCurrentQuestions(questions);
    setCurrentItems(items);
    setCurrentColors(colors);
    initGame(gameMode, questions);
    setValidationReport({
      type: null,
      status: 'idle',
      fileName: '',
      errors: [],
      warnings: [],
      recordsImportedCount: 0
    });
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'items' | 'colors' | 'questions') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      handleImportCSV(type, text, file.name);
    };
    reader.readAsText(file, 'utf-8');
    // Clear input value so same file can be uploaded again
    e.target.value = '';
  };

  const handleDrag = (e: React.DragEvent, type: 'items' | 'colors' | 'questions') => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActiveType(type);
    } else if (e.type === "dragleave") {
      setDragActiveType(null);
    }
  };

  const handleDrop = (e: React.DragEvent, type: 'items' | 'colors' | 'questions') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActiveType(null);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        handleImportCSV(type, text, file.name);
      };
      reader.readAsText(file, 'utf-8');
    }
  };

  const handleRecordAnswer = (questionId: number, answerText: string, isCorrect: boolean, scorePoints?: number) => {
    setLastSubmittedAnswers(prev => ({
      ...prev,
      [questionId]: { text: answerText, isCorrect }
    }));
    if (scorePoints !== undefined) {
      setQuestionScores(prev => {
        // Record only the first submitted score points
        if (prev[questionId] !== undefined) {
          return prev;
        }
        return {
          ...prev,
          [questionId]: scorePoints
        };
      });
    }
  };

  // Automatically switch phase based on the current question index in structured mode
  useEffect(() => {
    if (gameMode === 'structured') {
      if (currentQuestionIndex < 5) {
        setGamePhase(1);
      } else {
        setGamePhase(2);
      }
    }
  }, [currentQuestionIndex, gameMode]);

  // Precise millisecond stopwatch using requestAnimationFrame for performance
  useEffect(() => {
    if (!isGameStarted || showResultModal || isTutorialActive) return;

    let animFrameId: number;
    let lastTime = Date.now();

    const tick = () => {
      const now = Date.now();
      const delta = now - lastTime;
      lastTime = now;

      setTimeElapsedMs((prev) => prev + delta);

      animFrameId = requestAnimationFrame(tick);
    };

    animFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrameId);
  }, [isGameStarted, showResultModal, isTutorialActive]);

  // Handle game over when all 10 questions have been attempted
  useEffect(() => {
    const totalAttempted = Object.keys(questionResults).length;
    if (activeQuestions.length > 0 && totalAttempted === activeQuestions.length && !showResultModal) {
      // Small 1.5 seconds delay so that the final question answer feedback can be read
      const t = setTimeout(() => {
        playSound.success();
        setShowResultModal(true);
      }, 1500);
      return () => clearTimeout(t);
    }
  }, [questionResults, activeQuestions.length, showResultModal]);

  // Trigger smooth, premium Hakka-themed stage transition overlay whenever level shifts
  useEffect(() => {
    if (isGameStarted && activeQuestions.length > 0) {
      const q = activeQuestions[currentQuestionIndex];
      if (q) {
        setTransitionStageNum(currentQuestionIndex + 1);
        setTransitionTitle(q.restrictions || '');
        // Disable overlay on every question because user requested "不要每一題的過場動畫"
        // setShowTransitionOverlay(true);
        // 
        // const timer = setTimeout(() => {
        //   setShowTransitionOverlay(false);
        // }, 1100);
        // 
        // return () => clearTimeout(timer);
      }
    }
  }, [currentQuestionIndex, isGameStarted, activeQuestions]);

  const totalCorrect = Object.values(questionResults).filter(Boolean).length;

  // Active paper doll slots
  const [equippedItems, setEquippedItems] = useState<Record<SlotType, { item: ClothingItem; color: ColorType } | null>>({
    '頭部': null,
    '頸部': null,
    '軀幹': null,
    '下身': null,
    '腿部': null,
    '腳部': null,
  });

  const [lastEquipped, setLastEquipped] = useState<{ item: ClothingItem; color: ColorType } | null>(null);

  const currentQuestion = activeQuestions[currentQuestionIndex] || questions[0];

  // Equipped an item from the wardrobe
  const handleEquipItem = (item: ClothingItem, color: ColorType) => {
    setEquippedItems((prev) => ({
      ...prev,
      [item.slot]: { item, color },
    }));
    setLastEquipped({ item, color });
    // Auto reset selected slot focus once worn
    setSelectedSlot(null);
  };

  const handleClearSlot = (slot: SlotType) => {
    setEquippedItems((prev) => ({
      ...prev,
      [slot]: null,
    }));
  };

  const handleClearAllSlots = () => {
    setEquippedItems({
      '頭部': null,
      '頸部': null,
      '軀幹': null,
      '下身': null,
      '腿部': null,
      '腳部': null,
    });
    setLastEquipped(null);
    setSelectedSlot(null);
  };

  // Skip / Auto-populate a perfect dress-up solution for demo purposes
  const handleAutoSolve = () => {
    playSound.success();
    // Get the first correct combination string from currentQuestion.allowedAnswers
    const firstSolution = currentQuestion.allowedAnswers[0];
    if (!firstSolution) return;

    // Parse string format, e.g., "著 柑仔色个短衫" or "著 短衫"
    const parts = firstSolution.split(' ');
    const verb = parts[0]; // "著" or "戴"
    const clothingDescription = parts[1]; // "柑仔色个短衫" or "短衫"

    let colorName = '無';
    let itemName = clothingDescription;

    if (clothingDescription.includes('个')) {
      const subparts = clothingDescription.split('个');
      colorName = subparts[0];
      itemName = subparts[1];
    }

    // Find the actual item object from database
    const actualItem = requireItemFromDatabase(itemName);
    const actualColor = requireColorFromDatabase(colorName);

    if (actualItem && actualColor) {
      // Clear doll first, then equip the correct answer
      handleClearAllSlots();
      handleEquipItem(actualItem, actualColor);
    }
  };

  const handleSpeak = (text: string) => {
    playSound.click();
    if ('speechSynthesis' in window) {
      // Clean up parentheses for speech synthesis, e.g. "柑仔色 (橘色)" -> "柑仔色"
      const pureText = text.replace(/\([^)]*\)/g, '').trim();
      const utterance = new SpeechSynthesisUtterance(pureText);
      utterance.lang = 'zh-TW';
      utterance.rate = 0.8; // Slightly slower for language learners
      window.speechSynthesis.speak(utterance);
    }
  };

  const requireItemFromDatabase = (name: string): ClothingItem | null => {
    return currentItems.find((i: ClothingItem) => i.name === name) || null;
  };

  const requireColorFromDatabase = (name: string): ColorType | null => {
    if (name === '無') return currentColors[0];
    return currentColors.find((c: ColorType) => c.id === name) || currentColors[0];
  };

  // Jump navigations
  const handleNextQuestion = () => {
    if (currentQuestionIndex < activeQuestions.length - 1) {
      handleClearAllSlots();
      setLastEquipped(null);
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      handleClearAllSlots();
      setLastEquipped(null);
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSaveOutfit = async () => {
    playSound.success();
    const element = document.getElementById('paper-doll-canvas');
    if (!element) return;

    // We sanitize stylesheets of the main document because html2canvas parses styleSheets
    // of the active page first during setup, or copies them and tries to read cssRules.
    // By sanitizing the main document temporarily, we guarantee there is NO 'oklch'
    // in any style sheets that html2canvas can read.
    const styleBackups: { element: HTMLStyleElement; originalText: string }[] = [];
    const linkBackups: { element: HTMLLinkElement; placeholder: Comment }[] = [];
    const linkStyles: HTMLStyleElement[] = [];

    try {
      // 1. Sanitize <style> tags of the main document
      const styleTags = Array.from(document.getElementsByTagName('style'));
      for (const style of styleTags) {
        if (style.innerHTML && (style.innerHTML.includes('oklch') || style.innerHTML.includes('oklab'))) {
          styleBackups.push({
            element: style,
            originalText: style.innerHTML
          });
          style.innerHTML = style.innerHTML.replace(/oklch\([^)]*\)|oklab\([^)]*\)/gi, 'rgba(148, 163, 184, 0.5)');
        }
      }

      // 2. Sanitize <link> tags (external stylesheets) by temporarily replacing them
      // with a fetched & cleaned inline <style> tag.
      const linkTags = Array.from(document.querySelectorAll('link[rel="stylesheet"]')) as HTMLLinkElement[];
      for (const link of linkTags) {
        try {
          const href = link.href;
          if (href && (href.startsWith(window.location.origin) || href.startsWith('/') || !href.startsWith('http'))) {
            const response = await fetch(href);
            if (response.ok) {
              let cssText = await response.text();
              if (cssText.includes('oklch') || cssText.includes('oklab')) {
                cssText = cssText.replace(/oklch\([^)]*\)|oklab\([^)]*\)/gi, 'rgba(148, 163, 184, 0.5)');
                
                const tempStyle = document.createElement('style');
                tempStyle.setAttribute('data-temp-sanitized', 'true');
                tempStyle.innerHTML = cssText;
                
                const placeholder = document.createComment('link-placeholder');
                link.parentNode?.insertBefore(placeholder, link);
                document.head.appendChild(tempStyle);
                link.remove();
                
                linkBackups.push({ element: link, placeholder });
                linkStyles.push(tempStyle);
              }
            }
          }
        } catch (e) {
          console.warn('Could not sanitize link stylesheet:', link.href, e);
        }
      }

      const canvas = await html2canvas(element, {
        backgroundColor: '#ffffff',
        useCORS: true,
        scale: 2.5, // high resolution for crisp display
        logging: false,
        onclone: (clonedDoc) => {
          const win = clonedDoc.defaultView;
          if (!win) return;

          // 1. Hook getComputedStyle in the cloned window to transparently map any oklch color values to standard rgb equivalents
          const originalGetComputedStyle = win.getComputedStyle;
          win.getComputedStyle = function (elt, pseudoElt) {
            const style = originalGetComputedStyle.call(win, elt, pseudoElt);
            
            return new Proxy(style, {
              get(target, prop) {
                const val = Reflect.get(target, prop);
                if (typeof val === 'string' && (val.toLowerCase().includes('oklch') || val.toLowerCase().includes('oklab'))) {
                  // Fall back to slate-400 or transparent equivalent to avoid parsing issues
                  return val.replace(/oklch\([^)]*\)|oklab\([^)]*\)/gi, 'rgba(148, 163, 184, 0.5)');
                }
                if (typeof val === 'function') {
                  if (prop === 'getPropertyValue') {
                    return function (propertyName: string) {
                      const res = target.getPropertyValue(propertyName);
                      if (typeof res === 'string' && (res.toLowerCase().includes('oklch') || res.toLowerCase().includes('oklab'))) {
                        return res.replace(/oklch\([^)]*\)|oklab\([^)]*\)/gi, 'rgba(148, 163, 184, 0.5)');
                      }
                      return res;
                    };
                  }
                  return val.bind(target);
                }
                return val;
              }
            });
          };

          // 2. Sanitize any style tag content inside the cloned document
          const clonedStyleTags = clonedDoc.getElementsByTagName('style');
          for (let i = 0; i < clonedStyleTags.length; i++) {
            let cssText = clonedStyleTags[i].innerHTML;
            if (cssText && (cssText.toLowerCase().includes('oklch') || cssText.toLowerCase().includes('oklab'))) {
              cssText = cssText.replace(/oklch\([^)]*\)|oklab\([^)]*\)/gi, 'rgba(148, 163, 184, 0.5)');
              clonedStyleTags[i].innerHTML = cssText;
            }
          }

          // 3. Strip or clean stylesheet rules that contain oklch from document.styleSheets
          try {
            const stylesheets = clonedDoc.styleSheets;
            for (let i = 0; i < stylesheets.length; i++) {
              const sheet = stylesheets[i];
              try {
                if (sheet.cssRules) {
                  for (let j = sheet.cssRules.length - 1; j >= 0; j--) {
                    const rule = sheet.cssRules[j];
                    if (rule.cssText && (rule.cssText.toLowerCase().includes('oklch') || rule.cssText.toLowerCase().includes('oklab'))) {
                      sheet.deleteRule(j);
                    }
                  }
                }
              } catch (e) {
                // Ignore CORS sheets or unreadable sheets
              }
            }
          } catch (e) {
            console.warn('Error sanitizing oklch stylesheets:', e);
          }

          // 4. Clean any inline style attributes on cloned elements
          const clonedElements = clonedDoc.querySelectorAll('*');
          clonedElements.forEach((el) => {
            if (el instanceof HTMLElement) {
              const styleAttr = el.getAttribute('style');
              if (styleAttr && (styleAttr.toLowerCase().includes('oklch') || styleAttr.toLowerCase().includes('oklab'))) {
                const cleanStyle = styleAttr.replace(/oklch\([^)]*\)|oklab\([^)]*\)/gi, 'rgba(148, 163, 184, 0.5)');
                el.setAttribute('style', cleanStyle);
              }
              if (el.id === 'paper-doll-canvas') {
                el.style.backgroundColor = '#ffffff';
                el.style.border = '1px solid #e2e8f0';
              }
            }
          });
        }
      });

      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `客庄經典穿搭_關卡${currentQuestion.id === 0 ? '暖身例題' : currentQuestion.id}_${new Date().getTime()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (error) {
      console.error('儲存穿搭圖片失敗:', error);
    } finally {
      // Always restore original styles back to the main document so we don't break the active app
      for (const backup of styleBackups) {
        backup.element.innerHTML = backup.originalText;
      }
      for (const tempStyle of linkStyles) {
        tempStyle.remove();
      }
      for (const backup of linkBackups) {
        if (backup.placeholder && backup.placeholder.parentNode) {
          backup.placeholder.parentNode.insertBefore(backup.element, backup.placeholder);
          backup.placeholder.remove();
        }
      }
    }
  };

  const handleDownloadSouvenirSVG = () => {
    playSound.success();

    const slotLabelMap: Record<string, string> = {
      '頭部': '頭部配戴',
      '頸部': '頸部配件',
      '軀幹': '軀幹上著',
      '下身': '下半身裝',
      '腿部': '腿部襪飾',
      '腳部': '腳部鞋履'
    };

    // Collect active garments
    const equippedList: { slot: string; name: string; color: string; phonetic: string }[] = [];

    // Check equipped items
    Object.keys(equippedItems).forEach((slot) => {
      const equipped = equippedItems[slot as any];
      if (equipped) {
        equippedList.push({
          slot: slotLabelMap[slot] || slot,
          name: equipped.item.name,
          color: equipped.color.id,
          phonetic: equipped.item.phonetic
        });
      }
    });

    // Generate rows inside SVG
    const rowHeight = 44;
    const baseGapY = 245;
    const listElements = equippedList.map((eq, i) => {
      const currentY = baseGapY + (i * rowHeight);
      const label = eq.color !== '無' ? `${eq.color}个 ${eq.name}` : eq.name;
      return `
        <!-- Item Row ${i} -->
        <g transform="translate(35, ${currentY})">
          <rect width="430" height="36" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1"/>
          <rect width="75" height="36" rx="8" fill="#0d9488"/>
          <text x="37.5" y="22" fill="#ffffff" font-family="'Inter', sans-serif" font-size="11" font-weight="bold" text-anchor="middle">${eq.slot}</text>
          
          <text x="90" y="22" fill="#0f172a" font-family="'Inter', sans-serif" font-size="13" font-weight="bold">${label}</text>
          <text x="250" y="22" fill="#b45309" font-family="monospace" font-size="11" font-weight="bold">${eq.phonetic}</text>
        </g>
      `;
    }).join('');

    const cardTitle = currentQuestionIndex === 0 ? '暖身例題' : `任務關卡 ${currentQuestionIndex}`;

    const svgContent = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 650" width="100%" height="100%">
  <defs>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&amp;display=swap');
      .main-title { font-family: 'Inter', system-ui, sans-serif; font-weight: 900; }
      .text-sm { font-family: 'Inter', system-ui, sans-serif; }
      .stamp-text { font-family: 'Inter', system-ui, sans-serif; font-weight: 700; }
    </style>
  </defs>

  <!-- Outer elegant card background -->
  <rect width="500" height="650" rx="24" fill="#0f172a" />
  
  <!-- Outer decorative border -->
  <rect x="12" y="12" width="476" height="626" rx="20" fill="none" stroke="#be123c" stroke-width="2" opacity="0.4"/>
  
  <!-- Inner White Canvas -->
  <rect x="18" y="18" width="464" height="614" rx="18" fill="#ffffff" />
  
  <!-- Header Pattern Banner (Hakka Indigo Inspired with Floral Motif dots) -->
  <path d="M 18 18 L 482 18 L 482 145 C 482 145, 340 160, 250 145 C 160 130, 18 145, 18 145 Z" fill="#0d9488" />
  
  <!-- Subtle circular floral patterns in banner background -->
  <circle cx="250" cy="-10" r="110" fill="#ccfbf1" opacity="0.1" />
  <circle cx="420" cy="50" r="40" fill="#ffffff" opacity="0.08" />
  <circle cx="80" cy="90" r="30" fill="#ffffff" opacity="0.08" />

  <!-- Dots decorative grid representing Hakka textile stitch -->
  <circle cx="50" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="70" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="90" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="410" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="430" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  <circle cx="450" cy="40" r="2" fill="#ffffff" opacity="0.6"/>
  
  <!-- Header Title -->
  <text x="250" y="68" fill="#ffffff" class="main-title" font-size="24" font-weight="900" text-anchor="middle" letter-spacing="3">客庄穿搭留念卡</text>
  <text x="250" y="94" fill="#ccfbf1" class="text-sm" font-size="11" font-weight="700" text-anchor="middle" letter-spacing="1">阿梅的穿搭珍藏</text>
  
  <!-- Gold Clearance Star Badge -->
  <g transform="translate(180, 108)">
    <rect width="140" height="22" rx="11" fill="#be123c" />
    <text x="70" y="15" fill="#ffffff" class="text-sm" font-size="10" font-weight="bold" text-anchor="middle">★ 完美通關認證 ★</text>
  </g>
  
  <!-- Context Scenario Info Block -->
  <g transform="translate(35, 165)">
    <rect width="430" height="52" rx="10" fill="#fffbeb" stroke="#fef3c7" stroke-width="1"/>
    <text x="15" y="20" fill="#b45309" class="text-sm" font-size="10" font-weight="bold">挑戰關卡：${cardTitle}</text>
    <text x="15" y="38" fill="#0f172a" class="text-sm" font-size="12" font-weight="bold">情境限制：${currentQuestion?.restrictions || ''}</text>
  </g>
  
  <!-- Table Header -->
  <text x="38" y="235" fill="#64748b" class="text-sm" font-size="10" font-weight="bold" letter-spacing="1">【穿搭配件細節清單】</text>
  
  <!-- Render elements -->
  ${listElements}
  
  <!-- Red Hakka Seal Stamp -->
  <g transform="translate(370, 505)">
    <rect width="75" height="75" rx="10" fill="none" stroke="#be123c" stroke-width="2.5" stroke-dasharray="3 2" />
    <rect x="3" y="3" width="69" height="69" rx="8" fill="none" stroke="#be123c" stroke-width="1" />
    <text x="37.5" y="32" fill="#be123c" class="stamp-text" font-size="15" font-weight="bold" text-anchor="middle" letter-spacing="2">客庄</text>
    <text x="37.5" y="55" fill="#be123c" class="stamp-text" font-size="15" font-weight="bold" text-anchor="middle" letter-spacing="2">時尚</text>
  </g>
  
  <!-- Footer metadata and branding -->
  <line x1="35" y1="495" x2="465" y2="495" stroke="#f1f5f9" stroke-width="2" />
  
  <text x="35" y="525" fill="#64748b" class="text-sm" font-size="11" font-weight="bold">探索客家生活智慧，展現自信風采！</text>
  <text x="35" y="545" fill="#94a3b8" class="text-sm" font-size="10">系統平台：客語穿搭大挑戰</text>
  <text x="35" y="565" fill="#94a3b8" class="text-sm" font-size="9" font-family="monospace">時間印記：${new Date().toLocaleDateString('zh-TW')} ${new Date().toLocaleTimeString('zh-TW')}</text>
  <text x="35" y="585" fill="#0d9488" class="text-sm" font-size="10" font-weight="bold">Google AI Studio Build 認證製作</text>
</svg>
`;

    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `客庄穿搭留念卡_${currentQuestionIndex === 0 ? '暖身例題' : `關卡${currentQuestionIndex}`}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Calculate total progress
  const isAllCompleted = activeQuestions.length > 0 && totalCorrect === activeQuestions.length;
  const currentScore = activeQuestions.reduce((sum, q) => sum + (questionScores[q.id] || 0), 0);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans">
      {/* Traditional Hakka Red Flower Inspired Header */}
      <header className="bg-slate-900 border-b border-slate-800 relative text-white py-4 px-6 shadow-md overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-radial-gradient from-red-600/10 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center shadow-lg border border-white/10 animate-pulse">
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <div className="flex items-center flex-wrap gap-2">
                <h1 className="text-xl font-display font-extrabold tracking-wider bg-gradient-to-r from-white via-amber-200 to-rose-300 bg-clip-text text-transparent">
                  穿搭小達人
                </h1>
                {/* Seasonal restriction badge removed */}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
                輕量地端網頁 Demo：融合「穿著標籤」與「敘事句標籤」的完美客家穿搭交叉驗證引擎
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Stopwatch Timer with Millisecond Precision */}
            <div className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border font-bold transition-all duration-300 shadow ${
              !isGameStarted
                ? 'bg-slate-800 border-slate-700 text-slate-400'
                : 'bg-teal-50/15 border-teal-500/30 text-teal-300'
            }`}>
              <Timer size={14} className={isGameStarted ? 'animate-spin-slow text-teal-400' : ''} />
              <span className="text-xs font-mono tracking-wider">
                {!isGameStarted ? '⏱️ 00:00.00' : `⏱️ ${formatTime(timeElapsedMs)}`}
              </span>
            </div>

            {isGameStarted && currentView === 'game' && (
              <button
                onClick={() => {
                  playSound.click();
                  setIsTutorialActive(true);
                  setTutorialStep(0);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-amber-500/20 rounded-xl text-xs font-bold shadow transition duration-200 cursor-pointer"
                title="重新播放遊戲操作教學"
              >
                <Sparkles size={13} className="text-amber-400" />
                <span>💡 遊戲引導</span>
              </button>
            )}

            <button
              onClick={() => {
                playSound.click();
                setIsLearnModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold shadow transition duration-200 cursor-pointer bg-slate-800 hover:bg-slate-700 text-teal-200 hover:text-white border-teal-500/20"
            >
              <BookOpen size={13} />
              <span>📖 穿搭小詞典</span>
            </button>

            {/* Score pill */}
            <div className="flex items-center gap-2 bg-slate-800 px-4 py-1.5 rounded-xl border border-slate-750">
              <Trophy size={14} className="text-amber-400 animate-bounce" />
              <span className="text-xs font-bold text-slate-200">
                目前得分: <strong className="text-amber-300 text-sm font-black">{currentScore}</strong> / 100 分
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 flex flex-col gap-5 overflow-hidden">
        
        {!isGameStarted ? (
          <div className="flex flex-col gap-6 animate-fade-in max-w-4xl mx-auto py-2 w-full">
            {/* Header / Intro Card */}
            <div className="bg-white rounded-3xl border border-slate-200/80 p-6 md:p-8 shadow-sm flex flex-col md:flex-row gap-6 md:items-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full -mr-10 -mt-10 pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-teal-500/5 rounded-full -ml-10 -mb-10 pointer-events-none" />
              
              <div className="flex-1 space-y-4">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-800 rounded-full text-xs font-extrabold border border-amber-200">
                  <Sparkles size={12} className="animate-spin-slow text-amber-500" />
                  <span>阿梅的穿搭冒險</span>
                </div>
                <h2 className="text-2xl md:text-3xl font-display font-black text-slate-800 leading-tight">
                  歡迎來到 <span className="bg-gradient-to-r from-teal-600 via-amber-500 to-rose-600 bg-clip-text text-transparent">穿搭小達人！</span>
                </h2>
                <div className="text-xs md:text-sm text-slate-600 space-y-3.5 font-medium leading-relaxed">
                  <p className="text-slate-700 font-bold text-sm md:text-base bg-slate-50/80 p-4 rounded-2xl border border-slate-100 shadow-inner">
                    阿梅最愛出去玩，但出門前得先學會「看場合穿衣服」！翻開阿梅的衣櫃，發揮穿搭創意，幫阿梅避開尷尬的服裝災難，變身穿搭小達人吧！
                  </p>
                  
                  <div className="p-3.5 bg-teal-50/50 rounded-xl border border-teal-100/50 text-xs text-teal-900 font-bold">
                    <span className="block font-black text-teal-800 mb-1">▼遊玩提示</span>
                    玩家可事先閱讀課程專區I-III，學習客語單字。
                  </div>

                  <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200/50 text-xs">
                    <span className="block font-black text-slate-800 mb-2">▼遊玩計分</span>
                    <ol className="list-decimal pl-4 space-y-1 text-slate-600 font-bold">
                      <li>總遊玩分數，一題10分。</li>
                      <li>根據題目選擇合適的答案。</li>
                      <li>累計最高分及最低秒數(毫秒)為勝利。</li>
                    </ol>
                  </div>

                  <div className="p-3 bg-rose-50/60 rounded-xl border border-rose-100 text-xs text-rose-800 font-black flex items-center gap-2">
                    <span className="text-sm">⚠️</span>
                    <span>▼出門前記得上衣、下衣、鞋子都要穿好呦！</span>
                  </div>
                </div>
              </div>

              <div className="md:w-64 flex flex-col items-center justify-center border-t md:border-t-0 md:border-l border-slate-150 pt-6 md:pt-0 md:pl-6 shrink-0 gap-4">
                <div className="text-center">
                  <span className="text-[10px] text-slate-400 font-extrabold block uppercase tracking-widest mb-1">競速計時</span>
                  <span className="text-3xl font-black text-teal-600 font-mono tracking-tighter">正計時</span>
                  <span className="text-xs text-slate-500 font-bold block mt-1">（毫秒精確正計時）</span>
                </div>
                
                <button
                  onClick={() => {
                    playSound.success();
                    setIsGameStarted(true);
                    initGame();
                    if (needTutorial) {
                      setIsTutorialActive(true);
                      setTutorialStep(0);
                    }
                  }}
                  className="w-full py-4 bg-gradient-to-r from-amber-500 via-rose-500 to-teal-600 hover:from-amber-600 hover:to-teal-700 text-white font-extrabold rounded-2xl shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Sparkles className="animate-pulse" size={16} />
                  <span>開始穿搭挑戰！</span>
                </button>

                <label className="flex items-center gap-2 text-xs font-bold text-slate-500 cursor-pointer hover:text-slate-700 select-none">
                  <input
                    type="checkbox"
                    checked={needTutorial}
                    onChange={(e) => setNeedTutorial(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                  />
                  <span>開啟新手遊戲教學引導</span>
                </label>
              </div>
            </div>

            {/* CSV Dataset Download Area */}
            <div className="bg-gradient-to-br from-teal-500/5 via-transparent to-amber-500/5 rounded-3xl border border-slate-200/80 p-6 md:p-8 shadow-sm space-y-5">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-teal-50 rounded-xl text-teal-600 border border-teal-100 shrink-0 mt-0.5">
                  <Download size={18} />
                </div>
                <div>
                  <h3 className="font-display font-extrabold text-slate-800 text-base md:text-lg flex items-center gap-2">
                    <span>📥 客庄穿搭數據庫與教材 CSV 下載專區</span>
                    <span className="text-[10px] bg-teal-100 text-teal-800 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">Engineer & Educator Friendly</span>
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    本系統之傳統服飾配件標籤、二十關卡檢驗規則及傳統色卡，皆已轉換為標準數據規格設計。下方下載之 CSV 檔案其欄位名稱與系統內部資料模型（如：<code>ClothingItem</code>、<code>Question</code>、<code>ColorType</code>）完全一致，利於工程人員快速導入、解析或學術研究使用。
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                {/* Items Dataset Download Button */}
                <button
                  onClick={downloadItemsCSV}
                  className="p-4 bg-white border border-slate-200 rounded-2xl hover:border-teal-400 hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between text-left group min-h-[140px]"
                >
                  <div className="space-y-2">
                    <div className="p-2 bg-slate-50 rounded-xl group-hover:bg-teal-50 group-hover:text-teal-600 transition-colors w-fit">
                      <FileSpreadsheet size={20} className="text-slate-500 group-hover:text-teal-600" />
                    </div>
                    <div>
                      <span className="block text-xs md:text-sm font-black text-slate-800">
                        服飾配件數據庫
                      </span>
                      <span className="block text-[10px] md:text-[11px] text-slate-500 leading-tight mt-1">
                        含13種配件部位、客語拼音、翻譯、客語動詞與場合標籤等 {currentItems.length} 筆
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between w-full mt-3 pt-2 border-t border-slate-50 text-[10px] font-mono text-slate-400 group-hover:text-teal-600">
                    <span>hakka_clothing_items_db.csv</span>
                    <Download size={14} className="text-slate-400 group-hover:text-teal-600 transition-colors" />
                  </div>
                </button>

                {/* Colors Dataset Download Button */}
                <button
                  onClick={downloadColorsCSV}
                  className="p-4 bg-white border border-slate-200 rounded-2xl hover:border-rose-400 hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between text-left group min-h-[140px]"
                >
                  <div className="space-y-2">
                    <div className="p-2 bg-slate-50 rounded-xl group-hover:bg-rose-50 group-hover:text-rose-600 transition-colors w-fit">
                      <FileSpreadsheet size={20} className="text-slate-500 group-hover:text-rose-600" />
                    </div>
                    <div>
                      <span className="block text-xs md:text-sm font-black text-slate-800">
                        客庄傳統色彩資料集
                      </span>
                      <span className="block text-[10px] md:text-[11px] text-slate-500 leading-tight mt-1">
                        含柑仔色、大藍、烏色等7種傳統經典染色色彩與 HEX 網頁色碼等 {currentColors.length} 筆
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between w-full mt-3 pt-2 border-t border-slate-50 text-[10px] font-mono text-slate-400 group-hover:text-rose-600">
                    <span>hakka_clothing_colors_db.csv</span>
                    <Download size={14} className="text-slate-400 group-hover:text-rose-600 transition-colors" />
                  </div>
                </button>

                {/* Questions Dataset Download Button */}
                <button
                  onClick={downloadQuestionsCSV}
                  className="p-4 bg-white border border-slate-200 rounded-2xl hover:border-amber-400 hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between text-left group min-h-[140px]"
                >
                  <div className="space-y-2">
                    <div className="p-2 bg-slate-50 rounded-xl group-hover:bg-amber-50 group-hover:text-amber-600 transition-colors w-fit">
                      <FileSpreadsheet size={20} className="text-slate-500 group-hover:text-amber-600" />
                    </div>
                    <div>
                      <span className="block text-xs md:text-sm font-black text-slate-800">
                        關卡情境與檢驗規則
                      </span>
                      <span className="block text-[10px] md:text-[11px] text-slate-500 leading-tight mt-1">
                        含20關各情境節氣限制、客語描述、闖關提示與正確服飾檢驗邏輯 {currentQuestions.length} 筆
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between w-full mt-3 pt-2 border-t border-slate-50 text-[10px] font-mono text-slate-400 group-hover:text-amber-600">
                    <span>hakka_game_questions_db.csv</span>
                    <Download size={14} className="text-slate-400 group-hover:text-amber-600 transition-colors" />
                  </div>
                </button>
              </div>
            </div>

            {/* CSV Dataset Import Area with Rich Validation Feedback */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 md:p-8 shadow-sm space-y-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-150">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-gradient-to-tr from-teal-500 to-emerald-500 rounded-xl text-white shadow shrink-0 mt-0.5">
                    <Database size={18} />
                  </div>
                  <div>
                    <h3 className="font-display font-extrabold text-slate-800 text-base md:text-lg flex items-center gap-2">
                      <span>⚙️ 客庄穿搭數據庫自定義匯入主控制台 (CSV Import & Validation Console)</span>
                      <span className="text-[10px] bg-rose-500/10 text-rose-700 border border-rose-500/20 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">Developer & Educator Mode</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      開發人員可在此上傳自定義 CSV，即時覆蓋系統中的服飾、色彩與關卡數據。系統提供嚴格的表頭校驗、資料完整度驗證與跨欄位參考（Cross-reference）檢驗，並於校驗通過後自動更新遊戲與詞典！
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleRestoreDefaults}
                  className="px-4 py-2 text-slate-600 hover:text-slate-800 bg-slate-50 hover:bg-slate-100 font-extrabold rounded-xl text-xs shadow-sm hover:shadow transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200 shrink-0 self-start md:self-center"
                  title="還原為系統初始內建的客庄傳統數據與關卡規則"
                >
                  <RotateCcw size={14} />
                  <span>還原預設傳統數據</span>
                </button>
              </div>

              {/* Import Tab Switcher */}
              <div className="flex border-b border-slate-150">
                <button
                  onClick={() => { playSound.click(); setActiveImportTab('items'); }}
                  className={`py-2.5 px-4 font-extrabold text-xs md:text-sm border-b-2 transition-all cursor-pointer ${
                    activeImportTab === 'items'
                      ? 'border-teal-600 text-teal-600 font-black'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  👕 服飾配件匯入 (items)
                </button>
                <button
                  onClick={() => { playSound.click(); setActiveImportTab('colors'); }}
                  className={`py-2.5 px-4 font-extrabold text-xs md:text-sm border-b-2 transition-all cursor-pointer ${
                    activeImportTab === 'colors'
                      ? 'border-rose-600 text-rose-600 font-black'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  🎨 經典色彩匯入 (colors)
                </button>
                <button
                  onClick={() => { playSound.click(); setActiveImportTab('questions'); }}
                  className={`py-2.5 px-4 font-extrabold text-xs md:text-sm border-b-2 transition-all cursor-pointer ${
                    activeImportTab === 'questions'
                      ? 'border-amber-600 text-amber-600 font-black'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  🎯 關卡情境匯入 (questions)
                </button>
              </div>

              {/* Upload Drag & Drop Zone */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                <div className="lg:col-span-5 flex flex-col justify-between">
                  <div className="space-y-3">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1">
                      <span>📌 匯入 CSV 規範說明：</span>
                    </h4>
                    <ul className="text-[11px] text-slate-500 space-y-1.5 list-disc pl-4 font-medium leading-relaxed">
                      {activeImportTab === 'items' && (
                        <>
                          <li>必須包含 7 個表頭：<code className="text-teal-600 font-bold bg-teal-50 px-1 rounded font-mono">name, slot, phonetic, translation, desc, verb, tags</code></li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">slot</code> 必須為以下之一：<span className="font-bold text-slate-800">頭部, 頸部, 軀幹, 下身, 腿部, 腳部</span></li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">verb</code> 必須為以下之一：<span className="font-bold text-slate-800">著, 戴</span> (e.g. 戴帽仔、著短衫)</li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">tags</code> 為服裝場合或節氣標籤，多個請用英文分號 <code className="font-bold">;</code> 分隔 (e.g. <code className="font-mono text-slate-600">日常;夏天;防曬</code>)</li>
                        </>
                      )}
                      {activeImportTab === 'colors' && (
                        <>
                          <li>必須包含 5 個表頭：<code className="text-rose-600 font-bold bg-rose-50 px-1 rounded font-mono">id, name, hex, textHex, isPattern</code></li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">id</code> 為色彩唯一碼 (e.g. <code className="font-mono text-slate-600">大藍</code>)，<code className="font-mono bg-slate-50 px-1 rounded text-slate-700">name</code> 為翻譯或俗稱 (e.g. <code className="font-mono text-slate-600">大藍/藍衫色</code>)</li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">hex</code> 及 <code className="font-mono bg-slate-50 px-1 rounded text-slate-700">textHex</code> 必須為有效網頁色碼 (建議以 <code className="font-bold">#</code> 開頭)</li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">isPattern</code> 代表是否為花圖案 (布紋模式)，可填 <code className="font-mono text-slate-600">true</code> 或 <code className="font-mono text-slate-600">false</code></li>
                        </>
                      )}
                      {activeImportTab === 'questions' && (
                        <>
                          <li>必須包含 5 個表頭：<code className="text-amber-600 font-bold bg-amber-50 px-1 rounded font-mono">id, restrictions, narrative, hint, allowedAnswers</code></li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">id</code> 為正整數 (編號 1-7 為單空欄關卡，8-20 為雙空欄關卡)</li>
                          <li><code className="font-mono bg-slate-50 px-1 rounded text-slate-700">allowedAnswers</code> 為正確解答組合，多組請用英文分號 <code className="font-bold">;</code> 分隔 (e.g. <code className="font-mono text-slate-600">著 柑仔色个短衫;著 短衫</code>)</li>
                          <li>系統會自動與目前的<span className="font-bold text-slate-800">「服飾資料庫」</span>與<span className="font-bold text-slate-800">「色彩資料庫」</span>進行跨欄位關聯校驗</li>
                        </>
                      )}
                    </ul>
                  </div>

                  <div className="mt-4 p-3 bg-slate-50 border border-slate-150 rounded-xl text-[10px] text-slate-400 font-mono leading-tight">
                    <span>💡 推薦先下載上方專區的 CSV 範本，編輯後直接在此上傳，即可 100% 確保相容性！</span>
                  </div>
                </div>

                {/* Dropzone Container */}
                <div className="lg:col-span-7 flex flex-col gap-4">
                  <div
                    onDragEnter={(e) => handleDrag(e, activeImportTab)}
                    onDragOver={(e) => handleDrag(e, activeImportTab)}
                    onDragLeave={(e) => handleDrag(e, activeImportTab)}
                    onDrop={(e) => handleDrop(e, activeImportTab)}
                    className={`border-2 border-dashed rounded-2xl p-6 md:p-8 flex flex-col items-center justify-center text-center transition-all min-h-[200px] relative cursor-pointer group ${
                      dragActiveType === activeImportTab
                        ? 'border-teal-500 bg-teal-50/20'
                        : 'border-slate-300 hover:border-slate-400 bg-slate-50/50 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="file"
                      accept=".csv"
                      onChange={(e) => onFileChange(e, activeImportTab)}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      id={`csv-upload-input-${activeImportTab}`}
                    />
                    
                    <div className="space-y-2 pointer-events-none">
                      <div className={`p-3 bg-white rounded-full shadow-sm w-fit mx-auto transition-transform group-hover:scale-110 ${
                        activeImportTab === 'items' ? 'text-teal-600' : activeImportTab === 'colors' ? 'text-rose-600' : 'text-amber-600'
                      }`}>
                        <Upload size={24} />
                      </div>
                      <div>
                        <p className="text-xs md:text-sm font-black text-slate-800">
                          拖曳自定義 CSV 檔案至此，或 <span className={`underline ${
                            activeImportTab === 'items' ? 'text-teal-600' : activeImportTab === 'colors' ? 'text-rose-600' : 'text-amber-600'
                          }`}>點擊選取檔案</span>
                        </p>
                        <p className="text-[10px] md:text-[11px] text-slate-400 mt-1">
                          僅限 .csv 格式 (支援 UTF-8 編碼)
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Validation Feedback Report */}
                  {validationReport.type === activeImportTab && validationReport.status !== 'idle' && (
                    <div className={`rounded-2xl border p-4 text-xs space-y-3 animate-fade-in ${
                      validationReport.status === 'success'
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                        : validationReport.status === 'warning'
                        ? 'bg-amber-50 border-amber-200 text-amber-950'
                        : 'bg-rose-50 border-rose-200 text-rose-950'
                    }`}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2">
                          <div className={`p-1 rounded-lg shrink-0 mt-0.5 ${
                            validationReport.status === 'success'
                              ? 'bg-emerald-100 text-emerald-700'
                              : validationReport.status === 'warning'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-rose-100 text-rose-700'
                          }`}>
                            {validationReport.status === 'success' ? (
                              <CheckCircle size={14} />
                            ) : validationReport.status === 'warning' ? (
                              <AlertCircle size={14} />
                            ) : (
                              <ShieldAlert size={14} />
                            )}
                          </div>
                          <div>
                            <span className="font-black block">
                              檔案 {validationReport.fileName} 校驗結果：
                            </span>
                            <span className="block mt-0.5 font-bold">
                              {validationReport.status === 'success' && `✅ 匯入成功！已成功讀取、驗證並啟用 ${validationReport.recordsImportedCount} 筆數據，遊戲內關卡與詞典已即時刷新！`}
                              {validationReport.status === 'warning' && `⚠️ 匯入成功 (共 ${validationReport.recordsImportedCount} 筆)，但系統偵測到 ${validationReport.warnings.length} 個警示，請留意。`}
                              {validationReport.status === 'error' && `❌ 匯入失敗！檔案中存在 ${validationReport.errors.length} 個嚴重格式/結構錯誤，系統拒絕匯入。`}
                            </span>
                          </div>
                        </div>

                        {/* Clear/Dismiss Report Button */}
                        <button
                          onClick={() => setValidationReport({ type: null, status: 'idle', fileName: '', errors: [], warnings: [], recordsImportedCount: 0 })}
                          className="text-[10px] uppercase font-black hover:opacity-80 cursor-pointer text-slate-400 shrink-0 border border-slate-200/50 rounded px-1.5 py-0.5 bg-white/50"
                        >
                          清除
                        </button>
                      </div>

                      {/* Warning detail scroll container */}
                      {validationReport.warnings.length > 0 && (
                        <div className="space-y-1 bg-white/60 p-3 rounded-xl border border-amber-100 max-h-[140px] overflow-y-auto font-mono text-[10px] leading-relaxed">
                          <span className="block font-black text-amber-800 uppercase tracking-wide text-[9px] mb-1">
                            ⚠ 校驗警示細節 (Warnings - 可正常遊玩但可能造成邏輯未對應)：
                          </span>
                          {validationReport.warnings.map((w, i) => (
                            <div key={i} className="text-amber-800">• {w}</div>
                          ))}
                        </div>
                      )}

                      {/* Error detail scroll container */}
                      {validationReport.errors.length > 0 && (
                        <div className="space-y-1 bg-white/60 p-3 rounded-xl border border-rose-100 max-h-[140px] overflow-y-auto font-mono text-[10px] leading-relaxed">
                          <span className="block font-black text-rose-800 uppercase tracking-wide text-[9px] mb-1">
                            ❌ 嚴重錯誤細節 (Errors - 必須修正表頭或資料方能匯入)：
                          </span>
                          {validationReport.errors.map((e, i) => (
                            <div key={i} className="text-rose-800 font-bold">• {e}</div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Active Gameplay View */
          <>
            {/* Navigation Map Bar */}
            <div 
              id="tutorial-progress-bar"
              className={`bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm shrink-0 transition-all duration-300 ${
                isTutorialActive && tutorialStep === 4
                  ? 'relative z-[110] ring-4 ring-amber-400 shadow-[0_0_50px_rgba(251,191,36,0.4)] scale-[1.01]'
                  : ''
              }`}
            >
              {/* Sleek Progress Bar Container with 1/10 ➔ 2/10 text representation */}
              <div className="flex flex-col gap-3 py-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-100 shadow-xs">
                      當前關卡
                    </span>
                    <span className="text-sm font-black text-slate-700 font-mono tracking-wide">
                      {currentQuestionIndex + 1} / {activeQuestions.length}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-500 font-mono">
                    已完成: {Object.keys(questionResults).length} / {activeQuestions.length}
                  </div>
                </div>

                {/* Linear progress track and indicator dots */}
                <div className="relative pt-2 pb-1 px-1">
                  {/* Progress Line Background */}
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200/40 relative">
                    {/* Filled Progress segment representing current level */}
                    <div 
                      className="h-full bg-linear-to-r from-teal-500 to-emerald-500 rounded-full transition-all duration-300"
                      style={{ width: `${((currentQuestionIndex + 1) / activeQuestions.length) * 100}%` }}
                    />
                  </div>

                  {/* 10 Interactive Circles/Nodes aligned horizontally on the progress bar */}
                  <div className="absolute top-0 left-0 w-full h-6 flex justify-between px-0.5 pointer-events-none -mt-[3px]">
                    {activeQuestions.map((q, idx) => {
                      const isActive = currentQuestionIndex === idx;
                      const isAttempted = q.id in questionResults;
                      const isPassed = questionResults[q.id] === true;
                      
                      return (
                        <button
                          key={q.id}
                          onClick={() => {
                            playSound.click();
                            handleClearAllSlots();
                            setLastEquipped(null);
                            setCurrentQuestionIndex(idx);
                          }}
                          disabled={isTutorialActive}
                          className={`pointer-events-auto w-5.5 h-5.5 rounded-full flex items-center justify-center font-mono text-[9px] font-black transition-all duration-200 shadow-xs cursor-pointer ${
                            isActive
                              ? 'bg-teal-600 text-white ring-4 ring-teal-100 scale-120 z-10 border border-teal-500'
                              : isAttempted
                              ? isPassed
                                ? 'bg-emerald-500 text-white border border-emerald-400 hover:bg-emerald-600'
                                : 'bg-rose-500 text-white border border-rose-400 hover:bg-rose-600'
                              : 'bg-white text-slate-500 border border-slate-300 hover:bg-slate-50 hover:text-slate-800'
                          }`}
                          title={`第 ${idx + 1} 關: ${q.restrictions}`}
                        >
                          {isAttempted ? (isPassed ? '✓' : '✗') : idx + 1}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* 3-Panel Split Screen Grid with smooth fade-in/fade-out transition */}
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestionIndex}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 min-h-0"
              >
                {/* Panel 1: Mission Card (Left ~25%) */}
                <div 
                  id="tutorial-mission-card"
                  className={`lg:col-span-3 h-full min-h-[500px] transition-all duration-300 ${
                    isTutorialActive && tutorialStep === 1
                      ? 'relative z-[110] ring-4 ring-amber-400 bg-white rounded-3xl shadow-[0_0_50px_rgba(251,191,36,0.4)] scale-[1.02]'
                      : ''
                  }`}
                >
                  <MissionCard
                    currentQuestion={currentQuestion}
                    currentIndex={currentQuestionIndex}
                    totalQuestions={activeQuestions.length}
                    gamePhase={gamePhase}
                    onChangePhase={setGamePhase}
                    onNextQuestion={handleNextQuestion}
                    onPrevQuestion={handlePrevQuestion}
                    equippedItems={equippedItems}
                    lastEquipped={lastEquipped}
                    onClearAllSlots={handleClearAllSlots}
                    onJumpToQuestion={(idx) => {
                      handleClearAllSlots();
                      setLastEquipped(null);
                      setCurrentQuestionIndex(idx);
                    }}
                    questionResults={questionResults}
                    setQuestionResults={setQuestionResults}
                    questionScores={questionScores}
                    isAllCompleted={isAllCompleted}
                    gameMode={gameMode}
                    onRestart={() => initGame(gameMode)}
                    onEquipItem={handleEquipItem}
                    onRecordAnswer={handleRecordAnswer}
                    timeElapsedMs={timeElapsedMs}
                    itemDatabase={currentItems}
                    colorPalette={currentColors}
                  />
                </div>

                {/* Panel 2: Paper Doll (Middle ~50% - Largest Panel) */}
                <div 
                  id="tutorial-paper-doll"
                  className={`lg:col-span-6 h-full min-h-[500px] flex flex-col gap-3 transition-all duration-300 ${
                    isTutorialActive && tutorialStep === 2
                      ? 'relative z-[110] ring-4 ring-amber-400 bg-white rounded-3xl p-2 shadow-[0_0_50px_rgba(251,191,36,0.4)] scale-[1.02]'
                      : ''
                  }`}
                >
                  <PaperDoll
                    equippedItems={equippedItems}
                    selectedSlot={selectedSlot}
                    onSelectSlot={setSelectedSlot}
                    onClearSlot={handleClearSlot}
                    gender={gender}
                    onChangeGender={() => setGender(gender === '阿弟' ? '阿妹' : '阿弟')}
                    restrictions={currentQuestion?.restrictions}
                  />
                </div>

                {/* Panel 3: Wardrobe & Dye (Right ~25%) */}
                <div 
                  id="tutorial-closet"
                  className={`lg:col-span-3 h-full min-h-[500px] transition-all duration-300 ${
                    isTutorialActive && tutorialStep === 3
                      ? 'relative z-[110] ring-4 ring-amber-400 bg-white rounded-3xl shadow-[0_0_50px_rgba(251,191,36,0.4)] scale-[1.02]'
                      : ''
                  }`}
                >
                  <Closet
                    onEquipItem={handleEquipItem}
                    selectedSlot={selectedSlot}
                    equippedItems={equippedItems}
                    currentQuestion={currentQuestion}
                    itemDatabase={currentItems}
                    colorPalette={currentColors}
                    currentIndex={currentQuestionIndex}
                  />
                </div>
              </motion.div>
            </AnimatePresence>


          </>
        )}
      </main>

      {/* Hakka clothing Learn Modal / Dictionary */}
      <LearnModal 
        isOpen={isLearnModalOpen} 
        onClose={() => setIsLearnModalOpen(false)} 
        itemDatabase={currentItems}
        colorPalette={currentColors}
      />

      {/* Premium Hakka-themed Stage Transition Overlay */}
      <AnimatePresence>
        {showTransitionOverlay && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[120] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-none select-none"
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: -30 }}
              transition={{ type: "spring", damping: 26, stiffness: 190 }}
              className="bg-gradient-to-br from-teal-900 via-slate-900 to-emerald-950 border border-amber-400/30 rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl relative overflow-hidden flex flex-col items-center text-center gap-5"
            >
              {/* Floral design/lines decoration background */}
              <div className="absolute -right-8 -bottom-8 w-32 h-32 rounded-full border border-teal-500/10" />
              <div className="absolute -left-8 -top-8 w-32 h-32 rounded-full border border-teal-500/10" />
              
              {/* Spinning star emblem */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 6, ease: "linear" }}
                className="w-14 h-14 rounded-full border border-dashed border-amber-400/60 flex items-center justify-center text-amber-300 relative shrink-0 shadow-inner"
              >
                <Sparkles size={24} className="text-amber-400" />
              </motion.div>

              <div className="space-y-1.5 z-10">
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold px-2.5 py-1 rounded-full uppercase tracking-wider inline-block">
                  📖 進入下一關卡 (Next Stage)
                </span>
                <h3 className="text-2xl font-black text-white mt-1">
                  第 {transitionStageNum} 關 / 共 {activeQuestions.length} 關
                </h3>
                <div className="h-0.5 w-16 bg-gradient-to-r from-transparent via-amber-400 to-transparent mx-auto my-1" />
                <p className="text-sm font-extrabold text-teal-300">
                  {transitionTitle}
                </p>
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed mt-2 px-4">
                  客庄穿搭智慧，防曬避暑與大掃除，依據情境給予最合適的服裝防護！
                </p>
              </div>

              {/* Progress visual bar */}
              <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden border border-slate-700/30 shrink-0">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(transitionStageNum / activeQuestions.length) * 100}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  className="bg-gradient-to-r from-amber-400 to-teal-400 h-full rounded-full"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Game Over / Result Modal */}
      {showResultModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-fade-in" id="game-over-modal">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 relative flex flex-col items-center gap-5 scrollbar-thin">
            <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-teal-500 via-amber-500 to-rose-500" />
            
            <div className="w-16 h-16 rounded-full flex items-center justify-center border border-amber-200 text-amber-500 bg-amber-50 shadow-inner shrink-0 animate-bounce">
              <Trophy size={32} />
            </div>

            <div className="space-y-1 text-center">
              <h2 className="text-2xl font-black text-slate-800">
                🎉 恭喜完成挑戰！
              </h2>
              <p className="text-xs text-slate-500 font-bold">
                你成功挑戰了客庄常民經典穿搭考驗！
              </p>
            </div>

            {/* Score showcase */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 w-full flex justify-around items-center shrink-0">
              <div className="text-center">
                <span className="text-[10px] text-slate-400 font-extrabold block uppercase tracking-wider">最終得分</span>
                <span className="text-3xl font-black text-amber-500 font-mono">{currentScore}</span>
                <span className="text-xs font-bold text-slate-500 ml-1">分</span>
              </div>
              <div className="w-px h-10 bg-slate-200" />
              <div className="text-center">
                <span className="text-[10px] text-slate-400 font-extrabold block uppercase tracking-wider">答對題數</span>
                <span className="text-3xl font-black text-teal-600 font-mono">{totalCorrect}</span>
                <span className="text-xs font-bold text-slate-500 ml-1">/ 10</span>
              </div>
              <div className="w-px h-10 bg-slate-200" />
              <div className="text-center">
                <span className="text-[10px] text-slate-400 font-extrabold block uppercase tracking-wider">總消耗時間</span>
                <span className="text-xl font-black text-slate-700 font-mono block">{formatTime(timeElapsedMs)}</span>
              </div>
            </div>

            {/* Evaluation message */}
            <div className="p-3 bg-teal-50/50 rounded-xl border border-teal-100/50 text-xs text-slate-600 font-medium leading-relaxed w-full text-center shrink-0">
              {currentScore === 100 ? (
                <span className="text-teal-800 font-bold">👑 完美客庄穿搭大師！你已完全掌握客庄的生活智慧與衣著美學！</span>
              ) : currentScore >= 60 ? (
                <span className="text-teal-700 font-bold">🌟 優秀的客家庄行者！你已具備相當棒的客庄衣著智慧與應變能力！</span>
              ) : (
                <span className="text-rose-700 font-bold">⛰️ 客家庄的實習生！再玩一次，看看能不能獲得更高（答對更多題）的分數吧！</span>
              )}
            </div>

            {/* Detailed Question Review List */}
            <div className="w-full text-left space-y-3 border-t border-b border-slate-100 py-4">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                <span>📋 關卡穿搭與客語造句檢視：</span>
              </h3>
              
              <div className="space-y-3 max-h-[320px] overflow-y-auto pr-1">
                {activeQuestions.map((q, idx) => {
                  const isPassed = !!questionResults[q.id];
                  const submitted = lastSubmittedAnswers[q.id];
                  const chineseNumbers = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十"];
                  const questionLabel = `第${chineseNumbers[idx] || (idx + 1)}題`;
                  
                  return (
                    <div key={q.id} className={`p-3.5 rounded-2xl border text-xs leading-relaxed transition-all duration-200 ${
                      isPassed 
                        ? 'bg-emerald-50/40 border-emerald-100/70 text-emerald-950' 
                        : 'bg-rose-50/40 border-rose-100/70 text-rose-950'
                    }`}>
                      <div className="flex items-center justify-between gap-2 font-bold mb-1.5">
                        <span className="text-slate-500 font-bold text-[11px]">{questionLabel}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-slate-100 text-slate-700 border border-slate-200/50">
                            得分：{questionScores[q.id] !== undefined ? `${questionScores[q.id]} 分` : '0 分'}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            isPassed 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : 'bg-rose-100 text-rose-800'
                          }`}>
                            {isPassed ? '✓ 已通關' : '✗ 未通關/跳過'}
                          </span>
                        </div>
                      </div>
                      
                      {/* Display submitted answer as full sentence */}
                      <div className="flex flex-col gap-2 mt-1 p-2 bg-white/60 rounded-xl border border-slate-100">
                        {submitted ? (
                          <div>
                            <span className="font-bold text-slate-500 block text-[10px] uppercase tracking-wider mb-1">你組裝的客語句子：</span>
                            <span className={`font-sans text-sm ${
                              isPassed 
                                ? 'text-emerald-800 font-extrabold' 
                                : 'text-rose-700 line-through decoration-rose-500 decoration-2 font-extrabold'
                            }`}>
                              {submitted.text}{q.narrative}
                            </span>
                          </div>
                        ) : (
                          <div className="text-xs text-slate-400 italic">
                            <span>未進行此關搭配造句（未填答）</span>
                          </div>
                        )}
                      </div>

                      {/* Display reference or details if incorrect */}
                      {!isPassed && (
                        <div className="mt-2 bg-white/90 p-3 rounded-xl border border-rose-100/60 space-y-2 shadow-sm">
                          <div className="text-[11px] text-amber-800 leading-relaxed">
                            <span className="font-extrabold block">💡 客庄提示：</span>
                            {q.hint}
                          </div>
                          <div className="text-[11px] text-teal-800 leading-relaxed border-t border-slate-100 pt-1.5 font-serif">
                            <span className="font-bold block text-teal-900">👉 正確穿搭客語寫法之一：</span>
                            <code className="bg-teal-50 text-teal-900 px-1 py-0.5 rounded font-mono font-bold">{q.allowedAnswers[0]}</code>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <button
              onClick={() => {
                playSound.click();
                initGame();
              }}
              className="w-full py-3 bg-gradient-to-r from-teal-500 via-teal-600 to-emerald-600 hover:opacity-95 text-white rounded-2xl font-black text-sm shadow-lg shadow-teal-500/10 hover:shadow-teal-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              <RotateCcw size={15} />
              <span>重新抽題，再挑戰一局！ (Play Again)</span>
            </button>
          </div>
        </div>
      )}

      {/* Game Tutorial Guide Overlay */}
      <AnimatePresence>
        {isTutorialActive && (
          <>
            {/* Backdrop Mask */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/75 backdrop-blur-[2.5px] z-[100] pointer-events-auto"
            />

            {/* Float dialog */}
            <div className="fixed inset-x-4 bottom-6 md:bottom-12 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 z-[120] flex flex-col items-center pointer-events-auto max-w-xl w-full">
              <motion.div
                initial={{ y: 60, opacity: 0, scale: 0.93 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={{ y: 60, opacity: 0, scale: 0.93 }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="bg-white text-slate-800 rounded-3xl border border-amber-400/50 shadow-2xl p-6 w-full relative overflow-hidden flex flex-col gap-4"
              >
                {/* Cultural theme saffron border line on top */}
                <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-rose-500 to-teal-500" />
                
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <span className="text-[10px] bg-amber-500/10 text-amber-700 border border-amber-500/20 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider inline-block">
                      💡 遊戲操作引導 Step {tutorialStep + 1} / {TUTORIAL_STEPS.length}
                    </span>
                    <h4 className="text-base font-black text-slate-800 mt-1.5 flex items-center gap-1.5">
                      {TUTORIAL_STEPS[tutorialStep].title}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                      {TUTORIAL_STEPS[tutorialStep].subtitle}
                    </p>
                  </div>
                  
                  <button
                    onClick={() => {
                      playSound.click();
                      setIsTutorialActive(false);
                    }}
                    className="text-slate-400 hover:text-slate-600 transition p-1 hover:bg-slate-100 rounded-lg text-xs font-black"
                    title="跳過教學"
                  >
                    ✕ 跳過
                  </button>
                </div>

                <div className="text-xs text-slate-600 leading-relaxed font-semibold">
                  {TUTORIAL_STEPS[tutorialStep].desc}
                </div>

                <div className="p-3 bg-teal-50/70 border border-teal-100/50 rounded-2xl flex items-start gap-2 text-[11px] text-teal-800 font-semibold leading-normal">
                  <span className="shrink-0 text-base">💡</span>
                  <div>{TUTORIAL_STEPS[tutorialStep].tip}</div>
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between border-t border-slate-100 pt-4 mt-1">
                  <button
                    onClick={() => {
                      playSound.click();
                      setIsTutorialActive(false);
                    }}
                    className="text-xs text-slate-400 hover:text-slate-600 font-bold transition-all px-3 py-1.5 rounded-xl hover:bg-slate-100"
                  >
                    跳過教學 Skip
                  </button>
                  
                  <div className="flex items-center gap-2">
                    {tutorialStep > 0 && (
                      <button
                        onClick={() => {
                          playSound.click();
                          setTutorialStep(prev => prev - 1);
                        }}
                        className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition duration-150 cursor-pointer"
                      >
                        &larr; 上一步
                      </button>
                    )}
                    
                    <button
                      onClick={() => {
                        playSound.success();
                        if (tutorialStep < TUTORIAL_STEPS.length - 1) {
                          setTutorialStep(prev => prev + 1);
                        } else {
                          setIsTutorialActive(false);
                        }
                      }}
                      className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white font-extrabold rounded-xl text-xs shadow transition duration-150 flex items-center gap-1 cursor-pointer"
                    >
                      <span>{tutorialStep === TUTORIAL_STEPS.length - 1 ? '🎯 開始挑戰！' : '下一步 &rarr;'}</span>
                    </button>
                  </div>
                </div>

                {/* Dot indicator progress indicators */}
                <div className="flex justify-center gap-1.5 mt-1">
                  {TUTORIAL_STEPS.map((_, i) => (
                    <div
                      key={i}
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        i === tutorialStep ? 'w-4 bg-amber-500' : 'w-1.5 bg-slate-200'
                      }`}
                    />
                  ))}
                </div>
              </motion.div>
            </div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
