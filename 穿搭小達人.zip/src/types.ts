export type SlotType = '頭部' | '頸部' | '軀幹' | '下身' | '腿部' | '腳部';

export interface ClothingItem {
  name: string;
  slot: SlotType;
  phonetic: string;
  translation: string;
  desc: string;
  verb: '著' | '戴';
  tags: string[];
}

export interface ColorType {
  id: string;
  name: string;
  hex: string;
  textHex: string;
  isPattern?: boolean;
  phonetic?: string;
  translation?: string;
}

export interface Question {
  id: number;
  restrictions: string;
  narrative: string;
  allowedAnswers: string[]; // List of matching answers, e.g., ["著 白色个短衫", "著 白色个長褲"]
  hint: string;
}

export type GamePhase = 1 | 2; // Phase 1: Single Slot Matching, Phase 2: Full Interactive Dress-up
